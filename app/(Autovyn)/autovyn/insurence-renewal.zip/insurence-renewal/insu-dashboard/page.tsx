"use client";

import React, { useEffect, useState, useMemo, useCallback } from "react";
import Highcharts from "highcharts";
import HighchartsReact from "highcharts-react-official";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog2";
import DataTable from "@/components/Templates/reactTable";
import axios from "axios";
import { useCurrentUser } from "@/app/hooks/use-current-user";
import Ainput from "@/components/atoms/Input";
import {
  Shield,
  CheckCircle,
  AlertCircle,
  Clock,
  Bell,
  DollarSign,
  Hourglass,
  Building2,
  Search,
  X,
  Loader,
  AlertTriangle,
  RotateCcw,
  Calendar,
  Phone,
  MessageSquare,
  Tag,
  Smartphone,
  Target,
  Briefcase,
  ListChecks,
  Activity,
  RefreshCw,
  CheckCheck,
  XCircle,
  PhoneOff,
  WifiOff,
  Zap as Zap2,
  FileText,
  ThumbsUp,
  PieChart,
  ChevronRight,
} from "lucide-react";

// ─── SAFE PARSERS ─────────────────────────────────────────────────────────────
const si = (v: any): number => {
  const n = parseInt(String(v ?? 0), 10);
  return Number.isFinite(n) ? n : 0;
};
const sf = (v: any): number => {
  const n = parseFloat(String(v ?? 0));
  return Number.isFinite(n) ? n : 0;
};

// ─── FORMAT HELPERS ───────────────────────────────────────────────────────────
const fmtMoney = (n: number): string => {
  if (n >= 1_00_00_000) return `₹${(n / 1_00_00_000).toFixed(2)}Cr`;
  if (n >= 10_00_000) return `₹${(n / 10_00_000).toFixed(2)}L`;
  if (n >= 1_000) return `₹${(n / 1_000).toFixed(1)}K`;
  return `₹${n.toLocaleString("en-IN")}`;
};
const fmtN = (n: number): string => {
  if (n >= 10_00_000) return `${(n / 10_00_000).toFixed(1)}L`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`;
  return n.toLocaleString("en-IN");
};

// ─── FOLLOWUP META ────────────────────────────────────────────────────────────
const FU_META: Record<string, { color: string; icon: any; label: string }> = {
  RENEWED: { color: "#10b981", icon: CheckCheck, label: "Renewed" },
  NOT_INTERESTED: { color: "#ef4444", icon: XCircle, label: "Not Interested" },
  CALLBACK: { color: "#f59e0b", icon: Phone, label: "Callback" },
  PROMISED: { color: "#6366f1", icon: MessageSquare, label: "Promised" },
  INTERESTED: { color: "#3b82f6", icon: ThumbsUp, label: "Interested" },
  BUSY: { color: "#ec4899", icon: PhoneOff, label: "Busy" },
  NO_FOLLOWUP: { color: "#6b7280", icon: Tag, label: "No Follow-up" },
  AI_CALL_INITIATED: {
    color: "#8b5cf6",
    icon: Activity,
    label: "AI Call Initiated",
  },
  AI_CALL_PROCESSING: {
    color: "#a855f7",
    icon: RefreshCw,
    label: "AI Call Processing",
  },
  AI_CALL_COMPLETED: {
    color: "#7c3aed",
    icon: Target,
    label: "AI Call Completed",
  },
  AI_CALL_FAILED: {
    color: "#dc2626",
    icon: AlertTriangle,
    label: "AI Call Failed",
  },
  FOLLOWUP_DONE: {
    color: "#14b8a6",
    icon: ListChecks,
    label: "Follow-up Done",
  },
  PENDING: { color: "#f97316", icon: Hourglass, label: "Pending" },
  CALLED: { color: "#06b6d4", icon: Smartphone, label: "Called" },
  NO_ANSWER: { color: "#64748b", icon: PhoneOff, label: "No Answer" },
  DISCONNECTED: { color: "#94a3b8", icon: WifiOff, label: "Disconnected" },
};

const fuMeta = (s: string) => {
  const meta = FU_META[s];
  if (meta) return meta;
  return {
    color: "#64748b",
    icon: Tag,
    label: s
      .replace(/_/g, " ")
      .toLowerCase()
      .replace(/\b\w/g, (c) => c.toUpperCase()),
  };
};

// ─── TYPES ────────────────────────────────────────────────────────────────────
interface DashConfig {
  beforeDays: number;
  afterDays: number;
  periodType: string;
  periodLabel: string;
}
interface DashPayments {
  approvedCount: number;
  pendingCount: number;
  rejectedCount: number;
  totalCount: number;
  totalCollectedAmount: number;
  totalPremiumAmount: number;
  totalRejectedAmount: number;
  totalPendingAmount: number;
}
interface DashReminders {
  beforeExpiry: number;
  afterExpiry: number;
  totalDue: number;
  beforeDays: number;
  afterDays: number;
}
interface PeriodSummary {
  periodType: string;
  periodLabel: string;
  totalPolicies: number;
  collectedAmount: number;
  pendingAmount: number;
  rejectedAmount: number;
  totalPremium: number;
  approvedCount: number;
  rejectedCount: number;
  pendingCount: number;
}
interface DashSummary {
  totalPolicies: number;
  activePolicies: number;
  expiredPolicies: number;
  expiringIn30Days: number;
  reminders: DashReminders;
  payments: DashPayments;
  periodSummary: PeriodSummary;
}
interface FuItem {
  status: string;
  count: number;
}
interface PtItem {
  periodLabel: string;
  totalExpiring: number;
  collectedAmount: number;
  pendingCount: number;
  approvedCount: number;
  rejectedCount: number;
  rejectedAmount: number;
  pendingAmount: number;
  totalPremiumAmount: number;
  activePoliciesCount: number;
  expiredPoliciesCount: number;
}
interface CdItem {
  companyName: string;
  policyCount: number;
  totalPremium: number;
}
interface ExpRow {
  UTD: number;
  TRAN_ID: number;
  VEHICAL_REG_NO: string;
  CUST_NAME: string;
  CUST_MOB_NO: string;
  POLICY_NAME: string;
  POLICY_NUMBER: string;
  POLICY_END_DATE: string;
  DAYS_TO_EXPIRY: number;
  LAST_FOLLOWUP_STATUS?: string;
  LAST_FOLLOWUP_DATE?: string;
}
interface DashData {
  config: DashConfig;
  summary: DashSummary;
  charts: {
    followupBreakdown: FuItem[];
    periodTrend: PtItem[];
    companyDistribution: CdItem[];
  };
  tables: { recentExpiring: ExpRow[] };
}

// ─── MICRO COMPONENTS ─────────────────────────────────────────────────────────
const Sk = ({ h = "h-24", cls = "" }: { h?: string; cls?: string }) => (
  <div
    className={`animate-pulse rounded-2xl bg-gray-200 dark:bg-white/10 ${h} w-full ${cls}`}
  />
);

const ExpiryBadge = ({ days }: { days: number | null }) => {
  if (days === null || days === undefined)
    return <span className="text-[10px] text-gray-400">—</span>;
  const [bg, lbl] =
    days < 0
      ? [
          "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300 border-red-200",
          `${Math.abs(days)}d ago`,
        ]
      : days === 0
        ? [
            "bg-purple-100 text-purple-700 dark:bg-purple-900/30 border-purple-200",
            "Today!",
          ]
        : days <= 7
          ? [
              "bg-orange-100 text-orange-700 dark:bg-orange-900/30 border-orange-200",
              `${days}d left`,
            ]
          : days <= 15
            ? [
                "bg-amber-100 text-amber-700 dark:bg-amber-900/30 border-amber-200",
                `${days}d left`,
              ]
            : [
                "bg-green-100 text-green-700 dark:bg-green-900/30 border-green-200",
                `${days}d left`,
              ];

  return (
    <span
      className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold border ${bg}`}
    >
      {lbl}
    </span>
  );
};

const FuBadge = ({ status }: { status?: string }) => {
  if (!status)
    return (
      <span className="text-[10px] text-gray-400 dark:text-gray-500">—</span>
    );
  const m = fuMeta(status);
  const IconComponent = m.icon;
  return (
    <span
      className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold border whitespace-nowrap"
      style={{
        color: m.color,
        background: `${m.color}18`,
        borderColor: `${m.color}40`,
      }}
    >
      <IconComponent size={12} /> {m.label}
    </span>
  );
};

interface CardDef {
  label: string;
  value: string;
  icon: any;
  color: string;
  grad: string;
  sub?: string;
}

const StatCard = ({ c }: { c: CardDef }) => {
  const IconComponent = c.icon;
  return (
<div
  className="rounded-2xl bg-white dark:bg-[#161b22] dark:border-white/10 shadow-sm overflow-hidden w-full"
  style={{ borderTop: `4px solid ${c.color}` }}
>
      <div className="p-4 flex items-start justify-between gap-3 ">
        <div className="min-w-0">
          <div className="text-[11px] font-black tracking-widest uppercase text-gray-500 dark:text-gray-400">
            {c.label}
          </div>
          <div className="mt-2 text-3xl font-black text-gray-900 dark:text-white leading-none">
            {c.value}
          </div>
          {c.sub ? (
            <div className="mt-2 text-xs font-semibold text-gray-400 dark:text-gray-500">
              {c.sub}
            </div>
          ) : null}
        </div>

        <div
          className="w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 border"
          style={{
            background: `${c.color}12`,
            borderColor: `${c.color}33`,
            color: c.color,
          }}
        >
          <IconComponent size={18} />
        </div>
      </div>
    </div>
  );
};

const SecHd = ({
  icon,
  title,
  sub,
  badge,
  right,
}: {
  icon: any;
  title: string;
  sub?: string;
  badge?: { label: string; color: string };
  right?: React.ReactNode;
}) => {
  const IconComponent = icon;
  return (
    <div className="px-5 py-4 border-b border-gray-100 dark:border-white/10 flex items-start justify-between gap-3 bg-white dark:bg-[#161b22]">
      <div className="flex items-start gap-3">
        <div className="w-9 h-9 rounded-2xl bg-indigo-50 dark:bg-indigo-900/20 border border-indigo-100 dark:border-indigo-900/30 flex items-center justify-center text-indigo-600 dark:text-indigo-300 shrink-0">
          <IconComponent size={16} />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <div className="text-base font-black text-gray-900 dark:text-white">
              {title}
            </div>
            {badge ? (
              <span
                className="text-xs font-black px-3 py-1 rounded-full border"
                style={{
                  color: badge.color,
                  background: `${badge.color}12`,
                  borderColor: `${badge.color}30`,
                }}
              >
                {badge.label}
              </span>
            ) : null}
          </div>
          {sub ? (
            <div className="text-sm text-gray-500 dark:text-gray-400 -mt-0.5">
              {sub}
            </div>
          ) : null}
        </div>
      </div>
      {right}
    </div>
  );
};

const PRow = ({
  label,
  count,
  amount,
  maxCount,
  color,
}: {
  label: string;
  count: number;
  amount: number;
  maxCount: number;
  color: string;
}) => {
  const pct = maxCount > 0 ? Math.round((count / maxCount) * 100) : 0;
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between gap-3">
        <div className="text-sm font-bold text-gray-900 dark:text-white">
          {label}
        </div>
        <div className="text-sm font-extrabold" style={{ color }}>
          {fmtMoney(amount)} · {count} · {pct}%
        </div>
      </div>
      <div className="h-3 rounded-full bg-gray-100 dark:bg-white/10 overflow-hidden">
        <div
          className="h-full rounded-full transition-all duration-700"
          style={{
            width: `${Math.min(100, pct)}%`,
            background: color,
          }}
        />
      </div>
    </div>
  );
};

const PayTile = ({
  icon,
  title,
  value,
  bg,
  color,
  border,
}: {
  icon: any;
  title: string;
  value: string;
  bg: string;
  color: string;
  border: string;
}) => {
  const IconComponent = icon;
  return (
    <div className={`rounded-2xl border p-4 ${bg} ${border}`}>
      <div className="flex items-center gap-2 text-[11px] font-black tracking-widest uppercase text-gray-500 dark:text-gray-400">
        <span
          className="w-8 h-8 rounded-xl inline-flex items-center justify-center border"
          style={{ background: `${color}12`, borderColor: `${color}33` }}
        >
          <IconComponent size={14} style={{ color }} />
        </span>
        {title}
      </div>
      <div className="mt-3 text-3xl font-black" style={{ color }}>
        {value}
      </div>
    </div>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// MAIN PAGE
// ─────────────────────────────────────────────────────────────────────────────
export default function InsuranceDashboard() {
  const user = useCurrentUser();
  const BASE = `${process.env.NEXT_PUBLIC_URL}/excel`;

  const [dash, setDash] = useState<DashData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");

  const [dlgOpen, setDlgOpen] = useState(false);
  const [dlgTitle, setDlgTitle] = useState("");
  const [dlgData, setDlgData] = useState<any[]>([]);
  const [dlgCols, setDlgCols] = useState<any[]>([]);

  const fetchDash = useCallback(async () => {
    try {
      setLoading(true);
      setError("");

      const payload: Record<string, any> = {
        EXPORT_TYPE: 1,
        loc_code: user?.branch ?? "",
      };
      if (fromDate) payload.fromDate = fromDate;
      if (toDate) payload.toDate = toDate;

      const res = await axios.post(`${BASE}/dashboard`, payload, {
        headers: {
          "Content-Type": "application/json",
          compcode: user?.Comp_Code ?? "",
          name: user?.name ?? "",
        },
      });

      if (!res.data?.success) {
        setError(res.data?.Message || "Failed");
        return;
      }

      const rd = res.data?.data ?? {};
      const rs = rd?.summary ?? {};
      const rp = rs?.payments ?? {};
      const rr = rs?.reminders ?? {};
      const rc = rd?.charts ?? {};
      const rt = rd?.tables ?? {};
      const cfg = rd?.config ?? {};
      const rps = rs?.periodSummary ?? {};

      const filteredExpiring = (
        Array.isArray(rt.recentExpiring) ? rt.recentExpiring : []
      ).filter((row: ExpRow) => {
        const daysToExpiry = si(row.DAYS_TO_EXPIRY);
        return daysToExpiry >= 0 && daysToExpiry <= 30;
      });

      const normalized: DashData = {
        config: {
          beforeDays: si(cfg.beforeDays ?? rr.beforeDays ?? 30),
          afterDays: si(cfg.afterDays ?? rr.afterDays ?? 30),
          periodType: String(cfg.periodType ?? "monthly"),
          periodLabel: String(cfg.periodLabel ?? "month"),
        },
        summary: {
          totalPolicies: si(rs.totalPolicies),
          activePolicies: si(rs.activePolicies),
          expiredPolicies: si(rs.expiredPolicies),
          expiringIn30Days: si(rs.expiringIn30Days),
          reminders: {
            beforeExpiry: si(rr.beforeExpiry),
            afterExpiry: si(rr.afterExpiry),
            totalDue: si(rr.totalDue),
            beforeDays: si(cfg.beforeDays ?? rr.beforeDays ?? 30),
            afterDays: si(cfg.afterDays ?? rr.afterDays ?? 30),
          },
          payments: {
            approvedCount: si(rp.approvedCount),
            pendingCount: si(rp.pendingCount),
            rejectedCount: si(rp.rejectedCount),
            totalCount: si(rp.totalCount),
            totalCollectedAmount: sf(rp.totalCollectedAmount),
            totalPremiumAmount: sf(rp.totalPremiumAmount),
            totalRejectedAmount: sf(rp.totalRejectedAmount),
            totalPendingAmount: sf(rp.totalPendingAmount),
          },
          periodSummary: {
            periodType: String(rps.periodType ?? "monthly"),
            periodLabel: String(rps.periodLabel ?? "month"),
            totalPolicies: si(rps.totalPolicies),
            collectedAmount: sf(rps.collectedAmount),
            pendingAmount: sf(rps.pendingAmount),
            rejectedAmount: sf(rps.rejectedAmount),
            totalPremium: sf(rps.totalPremium),
            approvedCount: si(rps.approvedCount),
            rejectedCount: si(rps.rejectedCount),
            pendingCount: si(rps.pendingCount),
          },
        },
        charts: {
          followupBreakdown: (Array.isArray(rc.followupBreakdown)
            ? rc.followupBreakdown
            : []
          )
            .map((f: any) => ({
              status: String(f?.status ?? "UNKNOWN"),
              count: si(f?.count),
            }))
            .filter((f: any) => f.count > 0),
          periodTrend: (Array.isArray(rc.periodTrend)
            ? rc.periodTrend
            : []
          ).map((t: any) => ({
            periodLabel: String(t?.periodLabel ?? ""),
            totalExpiring: si(t?.totalExpiring),
            collectedAmount: sf(t?.collectedAmount),
            pendingCount: si(t?.pendingCount),
            approvedCount: si(t?.approvedCount),
            rejectedCount: si(t?.rejectedCount),
            rejectedAmount: sf(t?.rejectedAmount),
            pendingAmount: sf(t?.pendingAmount),
            totalPremiumAmount: sf(t?.totalPremiumAmount),
            activePoliciesCount: si(t?.activePoliciesCount),
            expiredPoliciesCount: si(t?.expiredPoliciesCount),
          })),
          companyDistribution: (Array.isArray(rc.companyDistribution)
            ? rc.companyDistribution
            : []
          ).map((c: any) => ({
            companyName: String(c?.companyName ?? "Other"),
            policyCount: si(c?.policyCount),
            totalPremium: sf(c?.totalPremium),
          })),
        },
        tables: { recentExpiring: filteredExpiring },
      };

      setDash(normalized);
    } catch (e: any) {
      setError(e?.response?.data?.Message || e?.message || "Server error");
    } finally {
      setLoading(false);
    }
  }, [fromDate, toDate, user, BASE]);

  useEffect(() => {
    fetchDash();
  }, [fetchDash]);

  const cfg = dash?.config;
  const s = dash?.summary;
  const p = s?.payments;
  const r = s?.reminders;
  const fb = dash?.charts.followupBreakdown ?? [];
  const cd = dash?.charts.companyDistribution ?? [];
  const ex = dash?.tables.recentExpiring ?? [];

  const payTotal =
    (p?.approvedCount ?? 0) +
      (p?.pendingCount ?? 0) +
      (p?.rejectedCount ?? 0) || 1;
  const fbTotal = fb.reduce((a, f) => a + f.count, 0) || 1;

  const cards = useMemo((): CardDef[] => {
    if (!s || !p || !r) return [];
    return [
      {
        label: "Total Policies",
        value: fmtN(s.totalPolicies),
        icon: FileText,
        color: "#2563eb",
        grad: "",
        sub: "All records",
      },
      {
        label: "Active",
        value: fmtN(s.activePolicies),
        icon: CheckCircle,
        color: "#16a34a",
        grad: "",
        sub: "Not expired",
      },
      {
        label: "Expired",
        value: fmtN(s.expiredPolicies),
        icon: AlertTriangle,
        color: "#d97706",
        grad: "",
        sub: "Past due date",
      },
      {
        label: "Expiring Soon",
        value: fmtN(s.expiringIn30Days),
        icon: Clock,
        color: "#e11d48",
        grad: "",
        sub: "Next 30 days",
      },
      {
        label: "Reminders Due",
        value: fmtN(r.totalDue),
        icon: Bell,
        color: "#7c3aed",
        grad: "",
        sub: `${r.beforeExpiry} before · ${r.afterExpiry} after`,
      },
      {
        label: "Collected",
        value: fmtMoney(p.totalCollectedAmount),
        icon: DollarSign,
        color: "#16a34a",
        grad: "",
        sub: `${p.approvedCount} approved`,
      },
      {
        label: "Pending Approval",
        value: fmtN(p.pendingCount),
        icon: Hourglass,
        color: "#6b7280",
        grad: "",
        sub: "Awaiting review",
      },
      {
        label: "Total Premium",
        value: fmtMoney(p.totalPremiumAmount),
        icon: Building2,
        color: "#2563eb",
        grad: "",
      },
    ];
  }, [s, p, r]);

  const donutOpts = useMemo(
    (): Highcharts.Options => ({
      chart: {
        type: "pie",
        backgroundColor: "transparent",
        style: { fontFamily: "inherit" },
        height: 220,
      },
      title: { text: undefined },
      credits: { enabled: false },
      tooltip: {
        backgroundColor: "#1e293b",
        borderColor: "transparent",
        borderRadius: 10,
        style: { color: "#f1f5f9" },
        pointFormat: "<b>{point.name}</b>: {point.y} ({point.percentage:.1f}%)",
      },
      plotOptions: {
        pie: {
          innerSize: "70%",
          borderWidth: 0,
          dataLabels: { enabled: false },
          showInLegend: false,
        },
      },
      series: [
        {
          type: "pie",
          name: "Follow-ups",
          data: fb.map((f) => ({
            name: fuMeta(f.status).label,
            y: f.count,
            color: fuMeta(f.status).color,
          })),
        },
      ],
    }),
    [fb],
  );

  const barOpts = useMemo(
    (): Highcharts.Options => ({
      chart: {
        type: "bar",
        backgroundColor: "transparent",
        style: { fontFamily: "inherit" },
        height: 220,
      },
      title: { text: undefined },
      credits: { enabled: false },
      xAxis: {
        categories: cd.map((c) =>
          c.companyName.length > 22
            ? c.companyName.slice(0, 22) + "…"
            : c.companyName,
        ),
        labels: { style: { color: "#94a3b8", fontSize: "10px" } },
        lineColor: "transparent",
        tickColor: "transparent",
      },
      yAxis: {
        title: { text: null },
        labels: { style: { color: "#94a3b8", fontSize: "10px" } },
        gridLineColor: "#e5e7eb",
      },
      legend: { enabled: false },
      plotOptions: {
        bar: {
          borderRadius: 8,
          borderWidth: 0,
          colorByPoint: true,
          colors: ["#6d28d9"],
        },
      },
      series: [
        { type: "bar", name: "Policies", data: cd.map((c) => c.policyCount) },
      ],
    }),
    [cd],
  );

  const openDlg = (title: string, rows: any[], cols: any[]) => {
    setDlgTitle(title);
    setDlgData(rows);
    setDlgCols(cols);
    setDlgOpen(true);
  };

  const EXPIRY_COLS = [
    { Header: "Vehicle", accessor: "VEHICAL_REG_NO" },
    { Header: "Customer", accessor: "CUST_NAME" },
    { Header: "Mobile", accessor: "CUST_MOB_NO" },
    { Header: "Policy No", accessor: "POLICY_NUMBER" },
    { Header: "Policy Name", accessor: "POLICY_NAME" },
    { Header: "Expires", accessor: "POLICY_END_DATE" },
    { Header: "Days Left", accessor: "DAYS_TO_EXPIRY" },
    { Header: "Last Followup", accessor: "LAST_FOLLOWUP_STATUS" },
    { Header: "FU Date", accessor: "LAST_FOLLOWUP_DATE" },
  ];

  return (
    <div className="min-h-screen bg-[#F3F6FF] dark:bg-[#0d1117] p-3 sm:p-4 space-y-4">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-xs text-gray-500 dark:bg-gray-400 px-1">
        <span className="font-semibold">Branch</span>
        <ChevronRight size={14} />
        <span>Autovyn</span>
        <ChevronRight size={14} />
        <span>CRM</span>
        <ChevronRight size={14} />
        <span>Insu_Renewal</span>
        <ChevronRight size={14} />
        <span className="px-3 py-1 rounded-full  dark:border-black bg-[#F3F6FF]  dark:bg-[#0D1117] text-indigo-700 dark:text-indigo-200 ">
          Insu-dashboard
        </span>
      </div>

      {/* HEADER */}
      <div
        className="rounded-3xl overflow-hidden shadow-xl"
        style={{
          background:
            "linear-gradient(135deg,#4f46e5 0%,#7c3aed 55%,#a855f7 100%)",
        }}
      >
        <div className="relative px-6 py-6">
          <div
            className="absolute inset-0 opacity-10"
            style={{
              backgroundImage:
                "radial-gradient(circle,white 1px,transparent 1px)",
              backgroundSize: "22px 22px",
            }}
          />

          <div className="relative flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-3xl bg-white/15 border border-white/15 flex items-center justify-center shadow-lg">
                <Shield size={24} className="text-white" />
              </div>
              <div>
                <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                  Insurance Renewal Dashboard
                </h1>
                <p className="text-white/75 text-sm mt-1">
                  Policies · Renewals · Payments · Follow-ups · Reminders
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 bg-white/15 border border-white/15 rounded-2xl px-4 py-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-white font-bold text-sm">
                Live ·{" "}
                {new Date().toLocaleDateString("en-IN", {
                  day: "numeric",
                  month: "short",
                  year: "numeric",
                })}
              </span>
            </div>
          </div>

          {/* Filter strip */}
          <div className="relative mt-6 bg-white/12 border border-white/15 rounded-3xl px-5 py-4 flex flex-wrap items-end gap-4">
            <div className="flex items-center gap-3 text-white/90 font-bold">
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
              <span className="flex items-center gap-2">
                <Search size={16} />
                Filter
              </span>
            </div>

            <div className="relative">
              <div className="[&_label]:!text-white [&_span]:!text-white">
                <Ainput
                  type="date"
                  title="From Date"
                  name="fromDate"
                  value={fromDate}
                  handleInputChange={(_n, v) => setFromDate(v)}
                  className="!bg-white dark:!bg-gray-800 !text-white dark:!text-white !h-10 !rounded-2xl !text-sm"
                  style={{
                    color: "white", 
                    colorScheme: "light",
                  }}
                />
              </div>
            </div>

            <div className="min-w-[180px]">
              <div className="[&_label]:!text-white [&_span]:!text-white">
                <Ainput
                  type="date"
                  title="To Date"
                  name="toDate"
                  value={toDate}
                  handleInputChange={(_n, v) => setToDate(v)}
                  className="!bg-white !text-gray-800 !h-10 !rounded-2xl !text-sm"
                />
              </div>
            </div>

            <button
              onClick={() => fetchDash()}
              disabled={loading}
              className="h-10 px-8 rounded-2xl bg-white text-indigo-700 font-black text-sm shadow
    hover:bg-white/90 
    dark:bg-black dark:text-white dark:hover:bg-gray-900
    disabled:opacity-60 disabled:cursor-not-allowed transition"
            >
              {loading ? (
                <span className="inline-flex items-center gap-2">
                  <Loader size={16} className="animate-spin" /> Loading…
                </span>
              ) : (
                "Apply"
              )}
            </button>

            {(fromDate || toDate) && (
              <button
                onClick={() => {
                  setFromDate("");
                  setToDate("");
                }}
                className="h-10 px-4 rounded-2xl border border-white/25 text-white text-sm font-bold hover:bg-white/10 transition inline-flex items-center gap-2"
              >
                <X size={16} /> Clear
              </button>
            )}

            {cfg && (
              <div className="ml-auto flex items-center gap-2">
                <span className="text-xs font-black text-white bg-white/15 border border-white/15 rounded-full px-4 py-2">
                  Before: {cfg.beforeDays}d
                </span>
                <span className="text-xs font-black text-white bg-white/15 border border-white/15 rounded-full px-4 py-2">
                  After: {cfg.afterDays}d
                </span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* ERROR */}
      {error && (
        <div className="rounded-2xl border border-red-200 dark:border-red-900/40 bg-red-50 dark:bg-red-900/20 px-4 py-3 flex items-center gap-3">
          <AlertTriangle size={20} className="text-red-600 shrink-0" />
          <div className="flex-1 min-w-0">
            <div className="text-sm font-bold text-red-700 dark:text-red-300">
              Error
            </div>
            <div className="text-xs text-red-600 dark:text-red-400 truncate">
              {error}
            </div>
          </div>
          <button
            onClick={() => fetchDash()}
            className="text-xs font-bold text-red-600 dark:text-red-400 underline shrink-0 hover:opacity-80 flex items-center gap-1"
          >
            <RotateCcw size={12} />
            Retry
          </button>
        </div>
      )}

      {/* STAT CARDS */}
      <div className="grid grid-cols-2 sm:grid-cols-4 xl:grid-cols-8 gap-3">
        {loading
          ? Array.from({ length: 8 }).map((_, i) => <Sk key={i} />)
          : cards.map((c, i) => <StatCard key={i} c={c} />)}
      </div>

      {/* REMINDER BANNER */}
      {!loading && r && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-3">
          {[
            {
              val: r.beforeExpiry,
              icon: Clock,
              label: "Before Expiry Reminders",
              desc: `Expiring in next ${r.beforeDays} days`,
              grad: "linear-gradient(135deg,#fb923c,#f97316)",
            },
            {
              val: r.afterExpiry,
              icon: AlertCircle,
              label: "After Expiry Reminders",
              desc: `Expired in last ${r.afterDays} days`,
              grad: "linear-gradient(135deg,#f43f5e,#e11d48)",
            },
            {
              val: r.totalDue,
              icon: Bell,
              label: "Total Reminders Due",
              desc: "Vehicles pending follow-up",
              grad: "linear-gradient(135deg,#6d28d9,#8b5cf6)",
            },
          ].map((rem) => {
            const RemIcon = rem.icon;
            return (
              <div
                key={rem.label}
                className="rounded-3xl overflow-hidden shadow-xl"
                style={{ background: rem.grad }}
              >
                <div className="relative p-6">
                  <div className="absolute right-0 top-0 w-44 h-44 rounded-full bg-white/15 -translate-y-1/3 translate-x-1/3" />
                  <div className="relative flex items-center gap-5">
                    <div className="w-14 h-14 rounded-2xl bg-white/15 border border-white/15 flex items-center justify-center">
                      <RemIcon size={24} className="text-white" />
                    </div>
                    <div className="min-w-0">
                      <div className="text-4xl font-black text-white leading-none">
                        {rem.val}
                      </div>
                      <div className="text-sm font-black text-white mt-2">
                        {rem.label}
                      </div>
                      <div className="text-xs text-white/80 mt-1">
                        {rem.desc}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* PAYMENT SUMMARY */}
      {!loading && p && (
        <div className="rounded-3xl border border-gray-200 dark:border-white/10 bg-white dark:bg-[#161b22] shadow-sm overflow-hidden">
          <SecHd
            icon={DollarSign}
            title="Payment Summary"
            sub="Approval breakdown & revenue metrics"
          />
          <div className="p-5 grid grid-cols-12 gap-5">
            <div className="col-span-12 lg:col-span-7 space-y-6">
              <PRow
                label="Approved"
                count={p.approvedCount}
                amount={p.totalCollectedAmount}
                maxCount={payTotal}
                color="#16a34a"
              />
              <PRow
                label="Pending Approval"
                count={p.pendingCount}
                amount={p.totalPendingAmount}
                maxCount={payTotal}
                color="#f59e0b"
              />
              <PRow
                label="Rejected"
                count={p.rejectedCount}
                amount={p.totalRejectedAmount}
                maxCount={payTotal}
                color="#e11d48"
              />
            </div>

            <div className="col-span-12 lg:col-span-5 grid grid-cols-1 sm:grid-cols-2 gap-4">
              <PayTile
                icon={DollarSign}
                title="Collected"
                value={fmtMoney(p.totalCollectedAmount)}
                bg="bg-[#EFFAF2] dark:bg-emerald-900/10 dark:text-black"
                border="border-[#BFE8CB] dark:border-white/10 text-black-600"
                color="#16a34a"
              />

              <PayTile
                icon={Building2}
                title="Total Premium"
                value={fmtMoney(p.totalPremiumAmount)}
                bg="bg-[#EEF4FF] dark:bg-indigo-900/10 dark:text-black"
                border="border-[#C7D6FF] dark:border-white/10"
                color="#1d4ed8"
              />

              <PayTile
                icon={CheckCircle}
                title="Approved"
                value={String(p.approvedCount)}
                bg="bg-[#EFFAF2] dark:bg-emerald-900/10 dark:text-black"
                border="border-[#BFE8CB] dark:border-white/10"
                color="#16a34a"
              />

              <PayTile
                icon={Hourglass}
                title="Pending"
                value={String(p.pendingCount)}
                bg="bg-[#FFF7E6] dark:bg-amber-900/10 dark:text-black"
                border="border-[#F3D29A] dark:border-white/10"
                color="#d97706"
              />
            </div>
          </div>
        </div>
      )}

      {/* CHARTS */}
      <div className="grid grid-cols-12 gap-3">
        <div className="col-span-12 lg:col-span-6 rounded-3xl border border-gray-200 dark:border-white/10 bg-white dark:bg-[#161b22] shadow-sm overflow-hidden">
          <SecHd
            icon={PieChart}
            title="Follow-up Breakdown"
            sub="Status distribution of all followups"
            badge={
              fb.length
                ? { label: `${fbTotal} total`, color: "#16a34a" }
                : undefined
            }
          />
          <div className="p-5">
            {loading ? (
              <Sk h="h-56" />
            ) : fb.length ? (
              <div className="grid grid-cols-12 gap-5 items-center">
                <div className="col-span-12 sm:col-span-5 relative">
                  <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none z-10">
                    <div className="text-3xl font-black text-gray-900 dark:text-white">
                      {fbTotal}
                    </div>
                    <div className="text-sm font-bold text-gray-400">total</div>
                  </div>
                  <HighchartsReact
                    highcharts={Highcharts}
                    options={donutOpts}
                  />
                </div>
                <div className="col-span-12 sm:col-span-7 space-y-3">
                  {fb.map((f) => {
                    const pct = Math.round((f.count / fbTotal) * 100);
                    const m = fuMeta(f.status);
                    const I = m.icon;
                    return (
                      <div
                        key={f.status}
                        className="rounded-2xl bg-gray-50 dark:bg-white/5 p-3 border border-gray-100 dark:border-white/10"
                      >
                        <div className="flex items-center justify-between gap-3">
                          <div className="flex items-center gap-2 min-w-0">
                            <span className="w-8 h-8 rounded-xl bg-white dark:bg-white/10 border border-gray-200 dark:border-white/10 flex items-center justify-center">
                              <I size={16} style={{ color: m.color }} />
                            </span>
                            <div className="text-sm font-bold text-gray-900 dark:text-white truncate">
                              {m.label}
                            </div>
                          </div>
                          <div className="text-sm font-black text-gray-900 dark:text-white shrink-0">
                            {f.count}{" "}
                            <span className="text-gray-400 font-bold">
                              ({pct}%)
                            </span>
                          </div>
                        </div>
                        <div className="mt-3 h-2 rounded-full bg-gray-200/70 dark:bg-white/10 overflow-hidden">
                          <div
                            className="h-full rounded-full"
                            style={{ width: `${pct}%`, background: m.color }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            ) : (
              <div className="h-48 flex items-center justify-center text-sm text-gray-400">
                No followup data
              </div>
            )}
          </div>
        </div>

        <div className="col-span-12 lg:col-span-6 rounded-3xl border border-gray-200 dark:border-white/10 bg-white dark:bg-[#161b22] shadow-sm overflow-hidden">
          <SecHd
            icon={Building2}
            title="Top Insurers"
            sub="By policy count"
            badge={
              cd.length
                ? { label: `Top ${cd.length}`, color: "#2563eb" }
                : undefined
            }
          />
          <div className="p-5">
            {loading ? (
              <Sk h="h-56" />
            ) : cd.length ? (
              <div className="space-y-4">
                {cd.slice(0, 1).map((c, idx) => {
                  const maxV = cd[0]?.policyCount || 1;
                  const pct = Math.round((c.policyCount / maxV) * 100);
                  return (
                    <div
                      key={c.companyName}
                      className="rounded-2xl border border-gray-100 dark:border-white/10 bg-gray-50 dark:bg-white/5 p-4"
                    >
                      <div className="flex items-center justify-between gap-3">
                        <div className="flex items-center gap-3 min-w-0">
                          <span className="w-10 h-10 rounded-xl bg-indigo-100 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-200 font-black flex items-center justify-center">
                            {idx + 1}
                          </span>
                          <div className="min-w-0">
                            <div className="text-sm font-black text-gray-900 dark:text-white truncate">
                              {c.companyName}
                            </div>
                          </div>
                        </div>
                        <div className="text-right shrink-0">
                          <div className="text-xl font-black text-indigo-700 dark:text-indigo-300">
                            {c.policyCount}
                          </div>
                          <div className="text-xs text-gray-400">
                            {fmtMoney(c.totalPremium)}
                          </div>
                        </div>
                      </div>
                      <div className="mt-3 h-3 rounded-full bg-gray-200/70 dark:bg-white/10 overflow-hidden">
                        <div
                          className="h-full rounded-full bg-indigo-600"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  );
                })}

                <div className="rounded-2xl border border-gray-100 dark:border-white/10 bg-white dark:bg-transparent p-2">
                  <HighchartsReact highcharts={Highcharts} options={barOpts} />
                </div>
              </div>
            ) : (
              <div className="h-48 flex items-center justify-center text-sm text-gray-400">
                No insurer data
              </div>
            )}
          </div>
        </div>
      </div>

      {/* EXPIRING SOON */}
      <div className="rounded-3xl border border-gray-200 dark:border-white/10 bg-white dark:bg-[#161b22] shadow-sm overflow-hidden">
        <SecHd
          icon={Zap2}
          title="Expiring Soon (Next 30 Days)"
          sub="Policies expiring in next 30 days · Double-click for details"
          badge={
            ex.length
              ? { label: `${ex.length} records`, color: "#f97316" }
              : undefined
          }
        />

        {loading ? (
          <div className="p-5 space-y-2">
            {Array.from({ length: 5 }).map((_, i) => (
              <Sk key={i} h="h-16" />
            ))}
          </div>
        ) : ex.length ? (
          <div className="p-5 space-y-2 max-h-[440px] overflow-auto">
            {ex.map((row, i) => (
              <div
                key={row.UTD ?? i}
                onDoubleClick={() =>
                  openDlg(`Policy — ${row.VEHICAL_REG_NO}`, [row], EXPIRY_COLS)
                }
                className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border
                  border-gray-100 dark:border-white/10 bg-gray-50 dark:bg-white/5
                  px-4 py-4 hover:bg-indigo-50 dark:hover:bg-indigo-900/10 transition cursor-pointer"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-10 h-10 rounded-xl bg-indigo-100 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-200 flex items-center justify-center text-sm font-black shrink-0">
                    {i + 1}
                  </div>
                  <div className="min-w-0">
                    <div className="text-sm font-black text-gray-900 dark:text-white">
                      {row.VEHICAL_REG_NO || "—"}
                    </div>
                    <div className="text-xs text-gray-500 dark:text-gray-400 truncate">
                      {row.CUST_NAME || "—"}
                      {row.CUST_MOB_NO ? ` · ${row.CUST_MOB_NO}` : ""}
                    </div>
                  </div>
                </div>

                <div className="text-sm font-black text-indigo-700 dark:text-indigo-300 truncate max-w-[160px]">
                  {row.POLICY_NUMBER || "—"}
                </div>

                <FuBadge status={row.LAST_FOLLOWUP_STATUS} />

                <div className="flex items-center gap-3 shrink-0">
                  <span className="text-sm font-bold text-gray-700 dark:text-gray-200">
                    {row.POLICY_END_DATE || "—"}
                  </span>
                  <ExpiryBadge days={si(row.DAYS_TO_EXPIRY)} />
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="h-44 flex flex-col items-center justify-center gap-2 text-gray-400">
            <span className="text-4xl">🎉</span>
            <span className="text-sm font-semibold">
              No policies expiring in next 30 days
            </span>
          </div>
        )}
      </div>

      {/* DIALOG */}
      <Dialog open={dlgOpen} onOpenChange={setDlgOpen}>
        <DialogContent className="w-[95vw] max-w-4xl max-h-[85vh] overflow-hidden flex flex-col rounded-2xl p-0">
          <div
            className="px-5 py-4 shrink-0 flex items-center gap-3"
            style={{ background: "linear-gradient(135deg,#4f46e5,#7c3aed)" }}
          >
            <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center text-lg">
              <FileText size={18} className="text-white" />
            </div>
            <div>
              <DialogTitle className="text-sm font-bold text-white m-0 p-0">
                {dlgTitle}
              </DialogTitle>
              <p className="text-white/70 text-[11px] mt-0.5">
                {dlgData.length} record{dlgData.length !== 1 ? "s" : ""}
              </p>
            </div>
          </div>

          <div className="flex-1 overflow-auto p-3 bg-[#F3F6FF] dark:bg-[#0d1117]">
            <div className="rounded-xl border border-gray-200 dark:border-white/10 bg-white dark:bg-[#161b22] overflow-hidden">
              <DataTable
                title=""
                columns={dlgCols}
                data={dlgData}
                selectValue="UTD"
                height="350px"
                filterPosition="FilterData"
                onRowDoubleClick={() => {}}
              />
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
