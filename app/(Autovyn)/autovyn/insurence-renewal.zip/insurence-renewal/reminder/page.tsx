"use client";

import React, { useEffect, useMemo, useState } from "react";
import axios from "axios";
import Swal from "sweetalert2";
import { useRouter } from "next/navigation";

import { Button } from "@/components/ui/button";
import DataTable from "@/components/Templates/reactTable";
import Ainput from "@/components/atoms/Input";
import HashloaderComponent from "@/components/Templates/hashloader";
import { useCurrentUser } from "@/app/hooks/use-current-user";

import {
  X,
  User,
  Phone,
  MapPin,
  LayoutGrid,
  PhoneCall,
  History,
  Bot,
  Clock3,
  CarFront,
  Shield,
  FileText,
  CalendarDays,
  MessageSquareText,
  Building2,
  BadgeIndianRupee,
  PhoneOff,
  PhoneForwarded,
  XCircle,
  CheckCircle2,
  Zap,
  Clock,
  PencilLine,
  Save,
  CalendarCheck2,
  Wrench,
} from "lucide-react";

// ============================================================
// HELPERS
// ============================================================
function showSideAlert(message: string, type: "success" | "error" | "warning") {
  const Toast = Swal.mixin({
    toast: true,
    position: "top-end",
    showConfirmButton: false,
    timer: 4000,
    timerProgressBar: true,
  });
  Toast.fire({ icon: type, title: message });
}

function ymdToDmy(ymd?: string | null) {
  if (!ymd) return "";
  const m = String(ymd).match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!m) return String(ymd);
  return `${m[3]}/${m[2]}/${m[1]}`;
}

function ymdToMdy(ymd?: string | null) {
  if (!ymd) return "";
  const m = String(ymd).match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!m) return String(ymd);
  const mm = Number(m[2]);
  const dd = Number(m[3]);
  return `${mm}/${dd}/${m[1]}`;
}

function time24To12(t?: string | null) {
  if (!t) return "";
  const m = String(t).match(/^(\d{2}):(\d{2})$/);
  if (!m) return String(t);
  let hh = Number(m[1]);
  const mm = m[2];
  const ampm = hh >= 12 ? "PM" : "AM";
  hh = hh % 12;
  if (hh === 0) hh = 12;
  return `${hh}:${mm} ${ampm}`;
}

const pad2 = (n: number) => String(n).padStart(2, "0");

function todayYMD() {
  const d = new Date();
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}

function tomorrowYMD() {
  const d = new Date();
  d.setDate(d.getDate() + 1);
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}

const normalizeVeh = (v: any) =>
  String(v || "")
    .toUpperCase()
    .replace(/\s+/g, "")
    .trim();

const ymdOnly = (v: any) => {
  if (!v) return "";
  const s = String(v);
  if (/^\d{4}-\d{2}-\d{2}/.test(s)) return s.slice(0, 10);
  return s;
};

function safeJsonParse(v: any) {
  if (v === null || v === undefined) return null;
  if (typeof v === "object") return v;
  if (typeof v !== "string") return v;
  try {
    return JSON.parse(v);
  } catch {
    return v;
  }
}

function prettyJson(v: any) {
  const parsed = safeJsonParse(v);
  if (parsed === null || parsed === undefined) return "";
  if (typeof parsed === "string") return parsed;
  try {
    return JSON.stringify(parsed, null, 2);
  } catch {
    return String(parsed);
  }
}

// ============================================================
// STATUS + UI
// ============================================================
const FOLLOWUP_STATUSES = [
  { value: "PROMISED", label: "PROMISED" },
  { value: "PENDING", label: "PENDING " },
  { value: "NOT_INTERESTED", label: "NOT INTERESTED" },
  { value: "RENEWED", label: "RENEWED" },
];

function statusPillClass(status: string) {
  switch (status) {
    case "RENEWED":
      return "bg-green-100 text-green-700 border border-green-200 dark:bg-green-900/30 dark:text-green-200 dark:border-green-800";
    case "NOT_INTERESTED":
      return "bg-red-100 text-red-700 border border-red-200 dark:bg-red-900/30 dark:text-red-200 dark:border-red-800";
    case "PENDING":
      return "bg-purple-100 text-purple-700 border border-purple-200 dark:bg-purple-900/30 dark:text-purple-200 dark:border-green-800";
    default:
      return "bg-blue-100 text-blue-700 border border-blue-200 dark:bg-blue-900/30 dark:text-blue-200 dark:border-blue-800";
  }
}

type TabType = "info" | "followup" | "history" | "aiCalling";
type ActionType = "NONE" | "NO_ANSWER" | "CALL_LATER" | "CLOSE" | "RENEWED";

const TabButton = ({
  label,
  icon,
  active,
  onClick,
  disabled,
}: {
  label: string;
  icon: React.ReactNode;
  active: boolean;
  onClick: () => void;
  disabled?: boolean;
}) => (
  <button
    onClick={onClick}
    disabled={disabled}
    className={`flex items-center gap-2 px-3 py-2 text-sm font-semibold
      transition-all duration-150 whitespace-nowrap rounded-xl border
      ${
        disabled
          ? "opacity-50 cursor-not-allowed border-transparent text-gray-400 dark:text-gray-500"
          : active
            ? "border-primary bg-blue-50 text-primary dark:bg-blue-900/10 dark:text-blue-300"
            : "border-transparent text-gray-500 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-white/5"
      }`}
  >
    <span className="inline-flex items-center justify-center">{icon}</span>
    <span>{label}</span>
  </button>
);

const SectionTitle = ({ title, icon }: { title: string; icon: string }) => (
  <div className="flex items-center gap-2 mb-3">
    <span className="text-sm">{icon}</span>
    <h3 className="text-[10px] font-bold uppercase tracking-widest text-gray-400 dark:text-gray-500 whitespace-nowrap">
      {title}
    </h3>
    <div className="flex-1 h-px bg-gray-200 dark:bg-borderColor-dark" />
  </div>
);

const InfoRow = ({ label, value }: { label: string; value: any }) => (
  <div className="flex justify-between items-center py-2 border-b last:border-0 border-gray-100 dark:border-borderColor-dark">
    <span className="text-[11px] text-gray-500 dark:text-gray-300 min-w-[130px] shrink-0">
      {label}
    </span>
    <span className="text-[11px] text-right dark:text-white font-medium break-all ml-2">
      {value ?? "—"}
    </span>
  </div>
);

const Field = ({
  label,
  required,
  children,
}: {
  label: string;
  required?: boolean;
  children: React.ReactNode;
}) => (
  <div className="flex flex-col gap-1">
    <label className="text-[11px] font-semibold text-gray-600 dark:text-gray-300">
      {label}
      {required && <span className="text-exit ml-0.5">*</span>}
    </label>
    {children}
  </div>
);

const inputCls =
  "h-9 w-full rounded-lg border border-gray-300 dark:border-borderColor-dark " +
  "bg-white dark:bg-input px-3 text-sm dark:text-white " +
  "focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent " +
  "placeholder:text-gray-400 dark:placeholder:text-gray-600 transition-shadow";

const panelInputCls =
  "h-11 w-full rounded-xl border border-[#E6ECF7] dark:border-borderColor-dark " +
  "bg-white dark:bg-input px-3 text-sm font-semibold text-gray-900 dark:text-white " +
  "focus:outline-none focus:ring-2 focus:ring-blue-200 focus:border-transparent transition";

const ActionBtn = ({
  label,
  active,
  color,
  onClick,
  disabled,
}: {
  label: string;
  active: boolean;
  color: "gray" | "blue" | "amber" | "red" | "green";
  onClick: () => void;
  disabled: boolean;
}) => {
  const colors: Record<string, { base: string; act: string }> = {
    gray: {
      base: "bg-gray-50 text-gray-700 hover:bg-gray-100 border border-gray-200 dark:bg-white/5 dark:text-gray-300 dark:border-borderColor-dark dark:hover:bg-white/10",
      act: "bg-white text-primary border border-gray-800 dark:bg-gray-700",
    },
    blue: {
      base: "bg-blue-50 text-blue-700 hover:bg-blue-100 border border-blue-200 dark:bg-blue-900/20 dark:text-blue-300 dark:border-blue-800 dark:hover:bg-blue-900/40",
      act: "bg-white text-primary border border-blue-600",
    },
    amber: {
      base: "bg-amber-50 text-amber-700 hover:bg-amber-100 border border-amber-200 dark:bg-amber-900/20 dark:text-amber-300 dark:border-amber-800",
      act: "bg-white text-primary border border-amber-600",
    },
    red: {
      base: "bg-red-50 text-red-700 hover:bg-red-100 border border-red-200 dark:bg-red-900/20 dark:text-red-300 dark:border-red-800",
      act: "bg-white text-primary border border-red-600",
    },
    green: {
      base: "bg-green-50 text-green-700 hover:bg-green-100 border border-green-200 dark:bg-green-900/20 dark:text-green-300 dark:border-green-800",
      act: "bg-white text-primary  border border-green-600",
    },
  };

  const c = colors[color] ?? colors.gray;

  return (
    <button
      className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all duration-150
        ${active ? c.act : c.base}
        ${
          disabled
            ? "opacity-40 cursor-not-allowed"
            : "cursor-pointer hover:scale-[1.02] active:scale-[0.98]"
        }`}
      onClick={onClick}
      disabled={disabled}
      type="button"
    >
      {label}
    </button>
  );
};

// ============================================================
// AI CALLING TAB
// ============================================================
function AiCallingTab({
  row,
  followupForm,
  aiGenerating,
  onGenerateAiCall,
  aiHistoryLoading,
  aiHistoryRows,
  onRefreshHistory,
}: {
  row: any;
  followupForm: any;
  aiGenerating: boolean;
  onGenerateAiCall: () => Promise<void>;
  aiHistoryLoading: boolean;
  aiHistoryRows: any[];
  onRefreshHistory: () => Promise<void>;
}) {
  const [selectedIdx, setSelectedIdx] = useState(-1);

  useEffect(() => {
    setSelectedIdx(-1);
  }, [row?.UTD, row?.VEHICAL_REG_NO]);

  useEffect(() => {
    if (aiHistoryRows?.length && selectedIdx === -1) setSelectedIdx(0);
  }, [aiHistoryRows?.length, selectedIdx]);

  const selected = selectedIdx >= 0 ? aiHistoryRows?.[selectedIdx] : null;

  const transcript = selected?.transcript ?? null;
  const summary = selected?.summary ?? null;
  const recordingUrl = selected?.recording_url ?? null;

  return (
    <div className="space-y-4">
      {/* AI CALL DETAILS */}
      <div className="rounded-2xl border border-[#E4D7FF] dark:border-borderColor-dark bg-[#F2EEFF] dark:bg-white/5 shadow-sm overflow-hidden">
        <div className="px-5 py-4 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <span className="w-10 h-10 rounded-2xl bg-[#EAF1FF] dark:bg-blue-500/10 inline-flex items-center justify-center shrink-0">
              <Bot className="w-5 h-5 text-blue-600 dark:text-blue-300" />
            </span>
            <div className="min-w-0">
              <div className="flex items-center gap-3">
                <div className="text-xs font-black tracking-widest uppercase text-gray-700 dark:text-gray-200">
                  AI CALL DETAILS
                </div>
                <div className="hidden sm:block flex-1 h-px bg-[#DDE6FF] dark:bg-white/10 w-32" />
              </div>

              <div className="mt-3 grid grid-cols-2 gap-x-10 gap-y-2 text-sm">
                <div className="flex gap-3">
                  <div className="text-gray-500 dark:text-gray-300 font-semibold">
                    Customer
                  </div>
                  <div className="text-gray-900 dark:text-white font-extrabold">
                    {row?.CUST_NAME ?? "—"}
                  </div>
                </div>

                <div className="flex gap-3">
                  <div className="text-gray-500 dark:text-gray-300 font-semibold">
                    Mobile
                  </div>
                  <div className="text-gray-900 dark:text-white font-extrabold">
                    {row?.CUST_MOB_NO ?? "—"}
                  </div>
                </div>

                <div className="flex gap-3">
                  <div className="text-gray-500 dark:text-gray-300 font-semibold">
                    Vehicle
                  </div>
                  <div className="text-gray-900 dark:text-white font-extrabold">
                    {followupForm?.VEHICAL_REG_NO ?? row?.VEHICAL_REG_NO ?? "—"}
                  </div>
                </div>

                <div className="flex gap-3">
                  <div className="text-gray-500 dark:text-gray-300 font-semibold">
                    Model
                  </div>
                  <div className="text-gray-900 dark:text-white font-extrabold">
                    {row?.MODEL_NAME ?? "—"}
                  </div>
                </div>
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={onGenerateAiCall}
            disabled={aiGenerating}
            className={`shrink-0 inline-flex items-center gap-2 rounded-xl px-5 py-3 text-sm font-extrabold shadow-lg
              bg-[#2F5BFF] hover:bg-[#274CF0] text-white transition
              ${aiGenerating ? "opacity-60 cursor-not-allowed" : ""}`}
          >
            <PhoneCall className="w-4 h-4" />
            {aiGenerating ? "Triggering…" : "Trigger AI Call"}
          </button>
        </div>
      </div>

      {/* CALL HISTORY */}
      <div className="rounded-2xl border border-[#E6ECF7] dark:border-borderColor-dark bg-white dark:bg-white/5 shadow-sm overflow-hidden">
        <div className="px-5 py-4 flex items-center justify-between gap-3 border-b border-[#E6ECF7] dark:border-borderColor-dark">
          <div className="flex items-center gap-3">
            <span className="w-10 h-10 rounded-2xl bg-[#EEF4FF] dark:bg-blue-500/10 inline-flex items-center justify-center">
              <History className="w-5 h-5 text-blue-600 dark:text-blue-300" />
            </span>
            <div className="text-xs font-black tracking-widest uppercase text-gray-700 dark:text-gray-200">
              CALL HISTORY
            </div>
          </div>

          <button
            type="button"
            onClick={onRefreshHistory}
            disabled={aiHistoryLoading}
            className={`inline-flex items-center gap-2 rounded-xl px-4 py-2 text-sm font-extrabold border
              border-blue-300/70 text-blue-700 bg-white hover:bg-blue-50 transition
              dark:bg-blue-900/10 dark:text-blue-200 dark:border-blue-900/40 dark:hover:bg-blue-900/20
              ${aiHistoryLoading ? "opacity-60 cursor-not-allowed" : ""}`}
          >
            <Clock3 className="w-4 h-4" />
            {aiHistoryLoading ? "Loading…" : "Load History"}
          </button>
        </div>

        <div className="p-5">
          {aiHistoryLoading ? (
            <div className="text-sm text-gray-600 dark:text-gray-300">
              Loading calling history...
            </div>
          ) : !aiHistoryRows || aiHistoryRows.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-[#D6E4FF] dark:border-white/10 bg-white/50 dark:bg-transparent p-10 flex flex-col items-center justify-center text-center">
              <PhoneCall className="w-10 h-10 text-rose-400" />
              <div className="mt-4 text-sm font-semibold text-gray-500 dark:text-gray-300">
                Click <b>"Load History"</b> to fetch call records
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-12 gap-4">
              {/* LIST */}
              <div className="col-span-12 md:col-span-6">
                <div className="max-h-[360px] overflow-auto rounded-xl border border-[#E6ECF7] dark:border-borderColor-dark bg-white dark:bg-transparent">
                  <table className="w-full text-xs border-collapse">
                    <thead>
                      <tr className="bg-[#F6F8FF] dark:bg-[#0F172A] sticky top-0">
                        <th className="border border-[#E6ECF7] dark:border-borderColor-dark px-2 py-2 text-left">
                          CALL ID
                        </th>
                        <th className="border border-[#E6ECF7] dark:border-borderColor-dark px-2 py-2 text-left">
                          STATUS
                        </th>
                        <th className="border border-[#E6ECF7] dark:border-borderColor-dark px-2 py-2 text-left">
                          PHONE
                        </th>
                        <th className="border border-[#E6ECF7] dark:border-borderColor-dark px-2 py-2 text-left">
                          START
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {aiHistoryRows.map((h, idx) => {
                        const active = idx === selectedIdx;
                        return (
                          <tr
                            key={idx}
                            className={`cursor-pointer hover:bg-[#F6F8FF] dark:hover:bg-[#0F172A] ${
                              active ? "bg-blue-50 dark:bg-blue-900/20" : ""
                            }`}
                            onClick={() => setSelectedIdx(idx)}
                          >
                            <td className="border border-[#E6ECF7] dark:border-borderColor-dark px-2 py-2">
                              {h?.call_id ?? "—"}
                            </td>
                            <td className="border border-[#E6ECF7] dark:border-borderColor-dark px-2 py-2">
                              {h?.status ?? "—"}
                            </td>
                            <td className="border border-[#E6ECF7] dark:border-borderColor-dark px-2 py-2">
                              {h?.phone_number ?? "—"}
                            </td>
                            <td className="border border-[#E6ECF7] dark:border-borderColor-dark px-2 py-2">
                              {String(h?.start_time ?? h?.triggered_at ?? "—")}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* DETAILS */}
              <div className="col-span-12 md:col-span-6">
                {!selected ? (
                  <div className="text-sm text-gray-600 dark:text-gray-300">
                    Select a call to view details.
                  </div>
                ) : (
                  <div className="rounded-2xl border border-[#E6ECF7] dark:border-borderColor-dark bg-white dark:bg-transparent p-4">
                    <div className="flex items-center gap-2 mb-3">
                      <div className="text-xs font-black tracking-widest uppercase text-gray-700 dark:text-gray-200">
                        CALL DETAILS
                      </div>
                      <div className="flex-1 h-px bg-[#E6ECF7] dark:bg-white/10" />
                    </div>

                    <div className="grid grid-cols-1 gap-1.5">
                      <InfoRow
                        label="Call ID"
                        value={selected?.call_id ?? "—"}
                      />
                      <InfoRow label="Status" value={selected?.status ?? "—"} />
                      <InfoRow
                        label="Phone"
                        value={selected?.phone_number ?? "—"}
                      />
                      <InfoRow
                        label="Start Time"
                        value={String(selected?.start_time ?? "—")}
                      />
                      <InfoRow
                        label="End Time"
                        value={String(selected?.end_time ?? "—")}
                      />
                      <InfoRow
                        label="Recording"
                        value={
                          recordingUrl ? (
                            <a
                              href={recordingUrl}
                              target="_blank"
                              rel="noreferrer"
                              className="text-primary underline"
                            >
                              Open Recording
                            </a>
                          ) : (
                            "—"
                          )
                        }
                      />
                    </div>

                    <div className="mt-4">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="text-xs font-black tracking-widest uppercase text-gray-700 dark:text-gray-200">
                          SUMMARY
                        </div>
                        <div className="flex-1 h-px bg-[#E6ECF7] dark:bg-white/10" />
                      </div>
                      <div className="text-xs text-gray-700 dark:text-gray-200 whitespace-pre-wrap">
                        {summary ? String(summary) : "—"}
                      </div>
                    </div>

                    <div className="mt-4">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="text-xs font-black tracking-widest uppercase text-gray-700 dark:text-gray-200">
                          TRANSCRIPT
                        </div>
                        <div className="flex-1 h-px bg-[#E6ECF7] dark:bg-white/10" />
                      </div>
                      <pre className="text-[11px] leading-relaxed whitespace-pre-wrap max-h-[220px] overflow-auto rounded-xl bg-[#F6F8FF] dark:bg-[#0F172A] p-3 border border-[#E6ECF7] dark:border-borderColor-dark">
                        {transcript ? prettyJson(transcript) : "—"}
                      </pre>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ============================================================
// MODAL - WITH FULL DATA INTEGRATION
// ============================================================
type InsuranceRow = any;

const InsuranceDetailModal = ({
  open,
  row,
  activeTab,
  onTabChange,
  onClose,
  followupForm,
  setFollowupForm,
  isSaving,
  onSave,
  historyLoading,
  historyRows,
  onLoadHistory,
  aiGenerating,
  onGenerateAiCall,
  aiHistoryLoading,
  aiHistoryRows,
  onLoadAiHistory,
}: {
  open: boolean;
  row: InsuranceRow | null;
  activeTab: TabType;
  onTabChange: (t: TabType) => void;
  onClose: () => void;
  followupForm: {
    VEHICAL_REG_NO: string;
    FOLLOWUP_DATE: string;
    FOLLOWUP_TIME: string;
    FOLLOWUP_STATUS: string;
    REMARKS: string;
  };
  setFollowupForm: React.Dispatch<
    React.SetStateAction<{
      VEHICAL_REG_NO: string;
      FOLLOWUP_DATE: string;
      FOLLOWUP_TIME: string;
      FOLLOWUP_STATUS: string;
      REMARKS: string;
    }>
  >;
  isSaving: boolean;
  onSave: (
    override?: Partial<{
      FOLLOWUP_DATE: string;
      FOLLOWUP_TIME: string;
      FOLLOWUP_STATUS: string;
      REMARKS: string;
    }>,
  ) => void;
  historyLoading: boolean;
  historyRows: any[];
  onLoadHistory: () => Promise<void>;
  aiGenerating: boolean;
  onGenerateAiCall: () => Promise<void>;
  aiHistoryLoading: boolean;
  aiHistoryRows: any[];
  onLoadAiHistory: () => Promise<void>;
}) => {
  const [activeAction, setActiveAction] = useState<ActionType>("NONE");

  const [noAnsDate, setNoAnsDate] = useState(tomorrowYMD());
  const [noAnsTime, setNoAnsTime] = useState("");
  const [noAnsRemark, setNoAnsRemark] = useState(
    "No answer – auto follow-up scheduled"
  );

  const [callLaterDate, setCallLaterDate] = useState("");
  const [callLaterTime, setCallLaterTime] = useState("16:00");
  const [callLaterRemark, setCallLaterRemark] = useState(
    "Customer asked to call back"
  );

  const [closeRemark, setCloseRemark] = useState("Not interested");
  const [renewRemark, setRenewRemark] = useState("Renewed");

  useEffect(() => {
    setActiveAction("NONE");
    setNoAnsDate(tomorrowYMD());
    setNoAnsTime("");
    setNoAnsRemark("No answer – auto follow-up scheduled");
    setCallLaterDate("");
    setCallLaterTime("16:00");
    setCallLaterRemark("Customer asked to call back");
    setCloseRemark("Not interested");
    setRenewRemark("Renewed");
  }, [row?.UTD, open]);

  if (!open) return null;

  const quickSet = (p: {
    FOLLOWUP_DATE: string;
    FOLLOWUP_STATUS: string;
    REMARKS: string;
    FOLLOWUP_TIME?: string;
  }) => {
    setFollowupForm((prev) => ({
      ...prev,
      FOLLOWUP_DATE: p.FOLLOWUP_DATE,
      FOLLOWUP_TIME: p.FOLLOWUP_TIME ?? prev.FOLLOWUP_TIME,
      FOLLOWUP_STATUS: p.FOLLOWUP_STATUS,
      REMARKS: p.REMARKS,
    }));
  };

  const CallInfoRow = ({
    k,
    v,
    highlight,
  }: {
    k: string;
    v: any;
    highlight?: boolean;
  }) => (
    <div className="py-3 flex items-center justify-between gap-4 border-b border-[#EEF2FF] dark:border-white/10 last:border-b-0">
      <div className="text-sm font-semibold text-gray-500 dark:text-gray-300">
        {k}
      </div>
      <div
        className={[
          "text-sm font-extrabold text-gray-900 dark:text-white text-right",
          highlight ? "text-blue-600 dark:text-blue-300" : "",
        ].join(" ")}
      >
        {v ?? "—"}
      </div>
    </div>
  );

  const ActionPill = ({
    active,
    onClick,
    disabled,
    icon,
    label,
    variant,
  }: {
    active: boolean;
    onClick: () => void;
    disabled: boolean;
    icon: React.ReactNode;
    label: string;
    variant: "red" | "blue" | "gray" | "green";
  }) => {
    const base =
      "inline-flex items-center gap-2 rounded-xl px-5 py-2.5 border text-sm font-extrabold shadow-sm transition bg-white dark:bg-white/5";
    const inactive =
      "border-[#E6ECF7] dark:border-borderColor-dark text-gray-700 dark:text-gray-200 hover:bg-[#F6F8FF] dark:hover:bg-white/10";

    const act =
      variant === "red"
        ? "bg-[#FFF1F2] border-[#FB7185] text-[#E11D48]"
        : variant === "blue"
          ? "bg-[#EEF4FF] border-[#60A5FA] text-[#2563EB]"
          : variant === "green"
            ? "bg-[#ECFDF5] border-[#34D399] text-[#059669]"
            : "bg-gray-50 border-gray-300 text-gray-800";

    return (
      <button
        type="button"
        disabled={disabled}
        onClick={onClick}
        className={[
          base,
          active ? act : inactive,
          disabled ? "opacity-60 cursor-not-allowed" : "",
        ].join(" ")}
      >
        {icon}
        {label}
      </button>
    );
  };

  return (
    <div
      className="fixed inset-0 z-[1000] flex items-end sm:items-center justify-center p-0 sm:p-2 md:p-4 bg-black/70 backdrop-blur-sm"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      role="dialog"
      aria-modal="true"
    >
      <div
        className="
          w-full h-[100dvh] sm:h-auto sm:max-h-[92vh] md:max-h-[90vh] md:max-w-5xl
          flex flex-col overflow-hidden
          rounded-none sm:rounded-2xl border border-gray-200 dark:border-borderColor-dark
          bg-white dark:bg-[#111827] shadow-2xl
          animate-in fade-in zoom-in-95 duration-200
        "
      >
        {/* ===== STICKY TOP AREA (HEADER + TABS) ===== */}
        <div className="shrink-0 sticky top-0 z-20">
          {/* HEADER */}
          <div className="relative overflow-hidden border-b border-white/10">
            <div className="absolute inset-0 bg-gradient-to-br from-[#061735] via-[#0B2A5A] to-[#0A1732]" />
            <div className="absolute inset-0 opacity-40 bg-[radial-gradient(circle_at_15%_20%,rgba(255,255,255,0.10),transparent_40%),radial-gradient(circle_at_80%_35%,rgba(255,255,255,0.10),transparent_45%)]" />
            <div className="relative px-4 sm:px-6 py-4 sm:py-5 text-white">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <h2 className="text-2xl sm:text-3xl font-black tracking-wide truncate max-w-[70vw]">
                      {row?.VEHICAL_REG_NO ??
                        followupForm.VEHICAL_REG_NO ??
                        "—"}
                    </h2>

                    {/* Policy Name / Insurer pill */}
                    {row?.POLICY_NAME ? (
                      <span className="inline-flex items-center rounded-full px-3 py-1 text-xs font-extrabold border border-white/15 bg-white/10">
                        {row.POLICY_NAME}
                      </span>
                    ) : row?.INSURER_NAME ? (
                      <span className="inline-flex items-center rounded-full px-3 py-1 text-xs font-extrabold border border-white/15 bg-white/10">
                        {row.INSURER_NAME}
                      </span>
                    ) : null}

                    {/* Type pill */}
                    {row?.type ? (
                      <span className="inline-flex items-center rounded-full px-3 py-1 text-xs font-extrabold border border-blue-300/25 bg-blue-500/15 text-blue-200">
                        {String(row.type).toUpperCase()}
                      </span>
                    ) : null}

                    {/* Status pill */}
                    <span
                      className={[
                        "inline-flex items-center rounded-full px-3 py-1 text-xs font-extrabold border",
                        String(followupForm.FOLLOWUP_STATUS || "")
                          .toUpperCase()
                          .includes("PENDING")
                          ? "border-amber-300/25 bg-amber-500/15 text-amber-200"
                          : String(followupForm.FOLLOWUP_STATUS || "")
                                .toUpperCase()
                                .includes("PROMISED")
                            ? "border-blue-300/25 bg-blue-500/15 text-blue-200"
                            : String(followupForm.FOLLOWUP_STATUS || "")
                                  .toUpperCase()
                                  .includes("RENEW")
                              ? "border-emerald-300/25 bg-emerald-500/15 text-emerald-200"
                              : String(followupForm.FOLLOWUP_STATUS || "")
                                    .toUpperCase()
                                    .includes("NOT")
                                ? "border-red-300/25 bg-red-500/15 text-red-200"
                                : "border-white/15 bg-white/10 text-white",
                      ].join(" ")}
                    >
                      {followupForm.FOLLOWUP_STATUS || "—"}
                    </span>
                  </div>

                  {/* sub line */}
                  <div className="mt-2 flex flex-wrap items-center gap-x-6 gap-y-2 text-sm font-semibold text-white/80">
                    <span className="inline-flex items-center gap-2 min-w-0">
                      <User className="w-4 h-4 opacity-90" />
                      <span className="truncate">{row?.CUST_NAME ?? "—"}</span>
                    </span>

                    <span className="inline-flex items-center gap-2">
                      <Phone className="w-4 h-4 opacity-90" />
                      <span className="truncate">
                        {row?.CUST_MOB_NO ?? "—"}
                      </span>
                    </span>

                   

                    {row?.POLICY_NUMBER ? (
                      <span className="inline-flex items-center gap-2 min-w-0">
                        <FileText className="w-4 h-4 opacity-90" />
                        <span className="truncate">{row.POLICY_NUMBER}</span>
                      </span>
                    ) : null}
                  </div>
                </div>

                <button
                  onClick={onClose}
                  className="w-10 h-10 shrink-0 rounded-xl border border-white/15 bg-white/10 hover:bg-white/15 transition inline-flex items-center justify-center"
                  aria-label="Close"
                  type="button"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>

          {/* TABS BAR */}
          <div className="bg-white dark:bg-[#111827] border-b border-[#E6ECF7] dark:border-borderColor-dark px-3 sm:px-5 py-3">
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-2 overflow-x-auto">
                <TabButton
                  label="Overview"
                  icon={<LayoutGrid className="w-4 h-4" />}
                  active={activeTab === "info"}
                  onClick={() => onTabChange("info")}
                />
                <TabButton
                  label="Call/Followup"
                  icon={<PhoneCall className="w-4 h-4" />}
                  active={activeTab === "followup"}
                  onClick={() => onTabChange("followup")}
                />

                <TabButton
                  label="AI Call"
                  icon={<Bot className="w-4 h-4" />}
                  active={activeTab === "aiCalling"}
                  onClick={async () => {
                    onTabChange("aiCalling");
                    await onLoadAiHistory();
                  }}
                />
              </div>

              <button
                type="button"
                onClick={async () => {
                  onTabChange("history");
                  await onLoadHistory();
                }}
                className="shrink-0 inline-flex items-center gap-2 rounded-xl px-4 py-2 text-sm font-extrabold border
                  border-blue-300/70 text-blue-700 bg-white hover:bg-blue-50
                  dark:bg-blue-900/10 dark:text-blue-200 dark:border-blue-900/40 dark:hover:bg-blue-900/20"
                title="All History"
              >
                <Clock3 className="w-4 h-4" />
                All History
              </button>
            </div>
          </div>
        </div>

        {/* BODY */}
        <div className="flex-1 overflow-y-auto px-3 sm:px-5 py-4 sm:py-5 bg-[#F6F8FF] dark:bg-[#111827]">
          {/* ===== OVERVIEW TAB ===== */}
          {activeTab === "info" && (
            <div className="space-y-4">
              {/* METRICS ROW (4 cards) */}
              <div className="grid grid-cols-12 justify-between gap-10">
                {/* REMINDER STATUS */}
                <div className="col-span-12 md:col-span-3 rounded-2xl border border-[#F3D7B3] dark:border-amber-900/30 bg-[#FFF4E6] dark:bg-amber-900/10 p-6 shadow-sm">
                  <div className="text-[11px] font-black tracking-widest uppercase text-gray-500/70 dark:text-gray-500">
                    REMINDER STATUS
                  </div>
                  <div className="mt-4">
                    <span className="inline-flex items-center rounded-full px-4 py-1.5 text-sm font-black border border-[#F2C27A] bg-[#FFE7C2] text-[#A65A00] dark:bg-amber-500/15 dark:text-amber-200 dark:border-amber-300/25">
                      {followupForm.FOLLOWUP_STATUS || "—"}
                    </span>
                  </div>
                </div>

               

                {/* DAYS UNTIL DUE */}
                <div className="col-span-12 md:col-span-3 rounded-2xl border border-[#E4D7FF] dark:border-violet-900/30 bg-[#F2EEFF] dark:bg-violet-900/10 p-6 shadow-sm">
                  <div className="text-[11px] font-black tracking-widest uppercase text-gray-500/70 dark:text-gray-500">
                    DAYS UNTIL DUE
                  </div>
                  <div className="mt-3 text-4xl font-black text-[#16A34A] dark:text-emerald-300">
                    {row?.days != null ? `${row.days}d` : "—"}
                  </div>
                </div>
              </div>

              {/* 3 INFO CARDS */}
              <div className="grid grid-cols-12 gap-4">
                {/* VEHICLE & CUSTOMER */}
                <div className="col-span-12 md:col-span-4 rounded-2xl border border-[#E6ECF7] dark:border-borderColor-dark bg-white dark:bg-white/5 overflow-hidden shadow-sm">
                  <div className="px-4 py-3 bg-white/70 dark:bg-transparent border-b border-[#E6ECF7] dark:border-borderColor-dark flex items-center gap-2">
                    <span className="w-9 h-9 rounded-xl bg-[#FFEFE1] dark:bg-orange-500/10 inline-flex items-center justify-center">
                      <CarFront className="w-4 h-4 text-orange-600 dark:text-orange-300" />
                    </span>
                    <div className="text-xs font-black tracking-widest uppercase text-gray-600 dark:text-gray-300">
                      VEHICLE & CUSTOMER
                    </div>
                    <div className="ml-2 flex-1 h-px bg-[#E6ECF7] dark:bg-white/10" />
                  </div>

                  <div className="px-4 py-2">
                    {[
                      [
                        "Reg No",
                        row?.VEHICAL_REG_NO ??
                          followupForm.VEHICAL_REG_NO ??
                          "—",
                      ],
                      ["Customer", row?.CUST_NAME ?? "—"],
                      ["Mobile", row?.CUST_MOB_NO ?? "—"],
                      ["Vehicle Model", row?.MODEL_NAME ?? "—"],
                     
                    ].map(([k, v], idx) => (
                      <div
                        key={k}
                        className={[
                          "py-3 flex items-center justify-between gap-4",
                          idx !== 4
                            ? "border-b border-[#EEF2FF] dark:border-white/10"
                            : "",
                        ].join(" ")}
                      >
                        <div className="text-sm font-semibold text-gray-500 dark:text-gray-300">
                          {k}
                        </div>
                        <div className="text-sm font-extrabold text-gray-900 dark:text-white text-right">
                          {v}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* POLICY INFO */}
                <div className="col-span-12 md:col-span-4 rounded-2xl border border-[#E6ECF7] dark:border-borderColor-dark bg-white dark:bg-white/5 overflow-hidden shadow-sm">
                  <div className="px-4 py-3 bg-white/70 dark:bg-transparent border-b border-[#E6ECF7] dark:border-borderColor-dark flex items-center gap-2">
                    <span className="w-9 h-9 rounded-xl bg-[#EAF1FF] dark:bg-blue-500/10 inline-flex items-center justify-center">
                      <Shield className="w-4 h-4 text-blue-600 dark:text-blue-300" />
                    </span>
                    <div className="text-xs font-black tracking-widest uppercase text-gray-600 dark:text-gray-300">
                      POLICY INFO
                    </div>
                    <div className="ml-2 flex-1 h-px bg-[#E6ECF7] dark:bg-white/10" />
                  </div>

                  <div className="px-4 py-2">
                    {[
                      ["Policy Name", row?.POLICY_NAME ?? "—"],
                      ["Policy Number", row?.POLICY_NUMBER ?? "—"],
                      ["Insurer", row?.INSURER_NAME ?? row?.POLICY_NAME ?? "—"],
                    
                    ].map(([k, v], idx) => (
                      <div
                        key={k}
                        className={[
                          "py-3 flex items-center justify-between gap-4",
                          idx !== 3
                            ? "border-b border-[#EEF2FF] dark:border-white/10"
                            : "",
                        ].join(" ")}
                      >
                        <div className="text-sm font-semibold text-gray-500 dark:text-gray-300">
                          {k}
                        </div>
                        <div className="text-sm font-extrabold text-gray-900 dark:text-white text-right">
                          {v}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* POLICY DATES */}
                <div className="col-span-12 md:col-span-4 rounded-2xl border border-[#E6ECF7] dark:border-borderColor-dark bg-white dark:bg-white/5 overflow-hidden shadow-sm">
                  <div className="px-4 py-3 bg-white/70 dark:bg-transparent border-b border-[#E6ECF7] dark:border-borderColor-dark flex items-center gap-2">
                    <span className="w-9 h-9 rounded-xl bg-[#F1ECFF] dark:bg-violet-500/10 inline-flex items-center justify-center">
                      <CalendarDays className="w-4 h-4 text-violet-600 dark:text-violet-300" />
                    </span>
                    <div className="text-xs font-black tracking-widest uppercase text-gray-600 dark:text-gray-300">
                      POLICY DATES
                    </div>
                    <div className="ml-2 flex-1 h-px bg-[#E6ECF7] dark:bg-white/10" />
                  </div>

                  <div className="px-4 py-2">
                    <div className="py-3 flex items-center justify-between gap-4 border-b border-[#EEF2FF] dark:border-white/10">
                      <div className="text-sm font-semibold text-gray-500 dark:text-gray-300">
                        Start Date
                      </div>
                      <div className="text-sm font-extrabold text-gray-900 dark:text-white text-right">
                        {row?.POLICY_START_DATE ?? "—"}
                      </div>
                    </div>

                    <div className="py-3 flex items-center justify-between gap-4 border-b border-[#EEF2FF] dark:border-white/10">
                      <div className="text-sm font-semibold text-gray-500 dark:text-gray-300">
                        End / Expiry Date
                      </div>
                      <div className="text-sm font-extrabold text-blue-600 dark:text-blue-300 text-right">
                        {row?.POLICY_END_DATE ?? "—"}
                      </div>
                    </div>

                   

                    <div className="py-3 flex items-center justify-between gap-4">
                      <div className="text-sm font-semibold text-gray-500 dark:text-gray-300">
                        Based On
                      </div>
                      <div className="text-sm font-extrabold text-gray-900 dark:text-white text-right">
                        {row?.BASED_ON ?? row?.BASED_TYPE ?? "DATE_BASED"}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* MESSAGE */}
              <div className="rounded-2xl border border-[#E6ECF7] dark:border-borderColor-dark bg-white dark:bg-white/5 overflow-hidden shadow-sm">
                <div className="px-4 py-3 bg-white/70 dark:bg-transparent border-b border-[#E6ECF7] dark:border-borderColor-dark flex items-center gap-2">
                  <span className="w-9 h-9 rounded-xl bg-[#E9FFF2] dark:bg-emerald-500/10 inline-flex items-center justify-center">
                    <MessageSquareText className="w-4 h-4 text-emerald-600 dark:text-emerald-300" />
                  </span>
                  <div className="text-xs font-black tracking-widest uppercase text-gray-600 dark:text-gray-300">
                    MESSAGE
                  </div>
                  <div className="ml-2 flex-1 h-px bg-[#E6ECF7] dark:bg-white/10" />
                </div>
                <div className="px-4 py-4 text-[12px] text-gray-700 dark:text-gray-300 whitespace-pre-wrap">
                  {row?.message ?? "—"}
                </div>
              </div>

              {/* Created / Updated */}
              <div className="text-xs font-semibold text-gray-400 dark:text-gray-500 flex flex-wrap gap-x-6 gap-y-2 pt-1">
                <span>
                  Created:{" "}
                  <span className="font-black">
                    {row?.CREATED_AT ?? row?.createdAt ?? "—"}
                  </span>
                </span>
                <span>
                  Updated:{" "}
                  <span className="font-black">
                    {row?.UPDATED_AT ?? row?.updatedAt ?? "—"}
                  </span>
                </span>
              </div>
            </div>
          )}

          {/* ===== FOLLOWUP TAB ===== */}
          {activeTab === "followup" && (
            <div className="space-y-4">
              {/* LAST CALL INFO */}
              <div className="rounded-2xl border border-[#E6ECF7] dark:border-borderColor-dark bg-white dark:bg-white/5 shadow-sm overflow-hidden">
                <div className="px-5 py-4 flex items-center gap-3 border-b border-[#E6ECF7] dark:border-borderColor-dark bg-white/70 dark:bg-transparent">
                  <span className="w-9 h-9 rounded-xl bg-[#FFE7EC] dark:bg-rose-500/10 inline-flex items-center justify-center">
                    <PhoneCall className="w-4 h-4 text-rose-600 dark:text-rose-300" />
                  </span>
                  <div className="text-xs font-black tracking-widest uppercase text-gray-600 dark:text-gray-300">
                    LAST CALL INFO
                  </div>
                  <div className="ml-2 flex-1 h-px bg-[#E6ECF7] dark:bg-white/10" />
                </div>

                <div className="px-5 py-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-x-10">
                    {/* LEFT */}
                    <div>
                      <div className="py-3 flex items-center justify-between gap-4 border-b border-[#EEF2FF] dark:border-white/10">
                        <div className="text-sm font-semibold text-gray-500 dark:text-gray-300">
                          Call Status
                        </div>
                        <div className="text-sm font-extrabold text-blue-600 dark:text-blue-300">
                          {followupForm.FOLLOWUP_STATUS || "—"}
                        </div>
                      </div>

                      <div className="py-3 flex items-center justify-between gap-4 border-b border-[#EEF2FF] dark:border-white/10">
                        <div className="text-sm font-semibold text-gray-500 dark:text-gray-300">
                          Policy Number
                        </div>
                        <div className="text-sm font-extrabold text-gray-900 dark:text-white text-right">
                          {row?.POLICY_NUMBER ?? "—"}
                        </div>
                      </div>

                      <div className="py-3 flex items-center justify-between gap-4">
                        <div className="text-sm font-semibold text-gray-500 dark:text-gray-300">
                          Followup Date
                        </div>
                        <div className="text-sm font-extrabold text-gray-900 dark:text-white text-right">
                          {followupForm.FOLLOWUP_DATE
                            ? ymdToMdy(followupForm.FOLLOWUP_DATE)
                            : "—"}
                        </div>
                      </div>
                    </div>

                    {/* RIGHT */}
                    <div>
                      <div className="py-3 flex items-center justify-between gap-4 border-b border-[#EEF2FF] dark:border-white/10">
                        <div className="text-sm font-semibold text-gray-500 dark:text-gray-300">
                          Policy Expiry
                        </div>
                        <div className="text-sm font-extrabold text-blue-600 dark:text-blue-300 text-right">
                          {row?.POLICY_END_DATE ?? "—"}
                        </div>
                      </div>

                      <div className="py-3 flex items-center justify-between gap-4">
                        <div className="text-sm font-semibold text-gray-500 dark:text-gray-300">
                          Followup Remark
                        </div>
                        <div className="text-sm font-extrabold text-gray-900 dark:text-white text-right truncate max-w-[260px]">
                          {followupForm.REMARKS || "—"}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-x-10">
                    <div className="py-3 flex items-center justify-between gap-4 border-t border-[#EEF2FF] dark:border-white/10">
                      <div className="text-sm font-semibold text-gray-500 dark:text-gray-300">
                        Insurer
                      </div>
                      <div className="text-sm font-extrabold text-gray-900 dark:text-white text-right">
                        {row?.POLICY_NAME ?? "—"}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* ACTIONS HEADER */}
              <div className="flex items-center gap-2">
                <span className="w-7 h-7 rounded-lg bg-[#FFF1C9] dark:bg-amber-500/10 inline-flex items-center justify-center">
                  <Zap className="w-4 h-4 text-amber-700 dark:text-amber-300" />
                </span>
                <div className="text-xs font-black tracking-widest uppercase text-gray-600 dark:text-gray-300">
                  ACTIONS
                </div>
                <div className="flex-1 h-px bg-[#E6ECF7] dark:bg-white/10" />
              </div>

              <div className="flex flex-wrap gap-3">
                <ActionPill
                  variant="red"
                  active={activeAction === "NO_ANSWER"}
                  disabled={isSaving}
                  onClick={() =>
                    setActiveAction(
                      activeAction === "NO_ANSWER" ? "NONE" : "NO_ANSWER"
                    )
                  }
                  icon={<PhoneOff className="w-4 h-4" />}
                  label="No Answer"
                />

                <ActionPill
                  variant="blue"
                  active={activeAction === "CALL_LATER"}
                  disabled={isSaving}
                  onClick={() =>
                    setActiveAction(
                      activeAction === "CALL_LATER" ? "NONE" : "CALL_LATER"
                    )
                  }
                  icon={<PhoneForwarded className="w-4 h-4" />}
                  label="Call Later"
                />

                <ActionPill
                  variant="red"
                  active={activeAction === "CLOSE"}
                  disabled={isSaving}
                  onClick={() =>
                    setActiveAction(
                      activeAction === "CLOSE" ? "NONE" : "CLOSE"
                    )
                  }
                  icon={<XCircle className="w-4 h-4" />}
                  label="Close"
                />

                <ActionPill
                  variant="green"
                  active={activeAction === "RENEWED"}
                  disabled={isSaving}
                  onClick={() =>
                    setActiveAction(
                      activeAction === "RENEWED" ? "NONE" : "RENEWED"
                    )
                  }
                  icon={<CheckCircle2 className="w-4 h-4" />}
                  label="Renewed"
                />
              </div>

              {/* NO ANSWER panel */}
              {activeAction === "NO_ANSWER" && (
                <div className="rounded-2xl border border-[#E6ECF7] dark:border-borderColor-dark bg-white dark:bg-white/5 shadow-sm overflow-hidden">
                  <div className="px-5 py-5 flex items-start gap-4 border-b border-[#E6ECF7] dark:border-borderColor-dark bg-[#FBFCFF] dark:bg-transparent">
                    <span className="w-12 h-12 rounded-2xl bg-[#FFE7EC] dark:bg-rose-500/10 inline-flex items-center justify-center shrink-0">
                      <PhoneOff className="w-5 h-5 text-rose-600 dark:text-rose-300" />
                    </span>
                    <div className="min-w-0">
                      <div className="text-xl font-black text-gray-900 dark:text-white">
                        No Answer
                      </div>
                      <div className="text-sm text-gray-500 dark:text-gray-300">
                        The call was not completed — the next follow-up will be
                        scheduled automatically.
                      </div>
                    </div>
                  </div>

                  <div className="px-5 py-5">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <label className="text-sm font-extrabold text-gray-700 dark:text-gray-200">
                          Next Follow-up Date{" "}
                          <span className="text-red-500">*</span>
                        </label>
                        <div className="mt-2 relative">
                          <CalendarDays className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                          <input
                            type="date"
                            className={`${panelInputCls} pl-10`}
                            value={noAnsDate}
                            onChange={(e) => {
                              const d = e.target.value;
                              setNoAnsDate(d);

                              const remark = [
                                noAnsRemark,
                                noAnsTime ? `(Call @ ${noAnsTime})` : "",
                              ]
                                .filter(Boolean)
                                .join(" ");

                              setFollowupForm((p) => ({
                                ...p,
                                FOLLOWUP_DATE: d,
                                FOLLOWUP_TIME: noAnsTime || "",
                                FOLLOWUP_STATUS: "PENDING",
                                REMARKS: remark,
                              }));
                            }}
                          />
                        </div>
                      </div>

                      <div>
                        <label className="text-sm font-extrabold text-gray-700 dark:text-gray-200">
                          Preferred Time (optional)
                        </label>
                        <div className="mt-2 relative">
                          <Clock className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                          <input
                            type="time"
                            className={`${panelInputCls} pl-10`}
                            value={noAnsTime}
                            onChange={(e) => {
                              const t = e.target.value;
                              setNoAnsTime(t);

                              const remark = [
                                noAnsRemark,
                                t ? `(Call @ ${t})` : "",
                              ]
                                .filter(Boolean)
                                .join(" ");

                              setFollowupForm((p) => ({
                                ...p,
                                FOLLOWUP_DATE: noAnsDate,
                                FOLLOWUP_TIME: t || "",
                                FOLLOWUP_STATUS: "PENDING",
                                REMARKS: remark,
                              }));
                            }}
                          />
                        </div>
                      </div>

                      <div>
                        <label className="text-sm font-extrabold text-gray-700 dark:text-gray-200">
                          Remark
                        </label>
                        <div className="mt-2 relative">
                          <PencilLine className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                          <input
                            type="text"
                            className={`${panelInputCls} pl-10`}
                            value={noAnsRemark}
                            onChange={(e) => {
                              const r = e.target.value;
                              setNoAnsRemark(r);

                              const remark = [
                                r,
                                noAnsTime ? `(Call @ ${noAnsTime})` : "",
                              ]
                                .filter(Boolean)
                                .join(" ");

                              setFollowupForm((p) => ({
                                ...p,
                                FOLLOWUP_DATE: noAnsDate,
                                FOLLOWUP_TIME: noAnsTime || "",
                                FOLLOWUP_STATUS: "PENDING",
                                REMARKS: remark,
                              }));
                            }}
                          />
                        </div>
                      </div>
                    </div>

                    <div className="mt-5">
                      <button
                        type="button"
                        disabled={isSaving}
                        onClick={() => {
                          const remark = [
                            noAnsRemark,
                            noAnsTime ? `(Call @ ${noAnsTime})` : "",
                          ]
                            .filter(Boolean)
                            .join(" ");

                          quickSet({
                            FOLLOWUP_DATE: noAnsDate,
                            FOLLOWUP_TIME: noAnsTime,
                            FOLLOWUP_STATUS: "PENDING",
                            REMARKS: remark,
                          });

                          onSave({
                            FOLLOWUP_DATE: noAnsDate,
                            FOLLOWUP_TIME: noAnsTime,
                            FOLLOWUP_STATUS: "PENDING",
                            REMARKS: remark,
                          });
                        }}
                        className={`inline-flex items-center gap-2 rounded-xl px-6 py-3 text-sm font-extrabold shadow-lg transition
                          bg-[#2F5BFF] hover:bg-[#274CF0] text-white
                          ${isSaving ? "opacity-60 cursor-not-allowed" : ""}`}
                      >
                        <Save className="w-4 h-4" />
                        {isSaving ? "Saving…" : "Schedule Follow-Up"}
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* CALL LATER panel */}
              {activeAction === "CALL_LATER" && (
                <div className="rounded-2xl border border-[#E6ECF7] dark:border-borderColor-dark bg-white dark:bg-white/5 shadow-sm overflow-hidden">
                  <div className="px-5 py-5 flex items-start gap-4 border-b border-[#E6ECF7] dark:border-borderColor-dark bg-[#FBFCFF] dark:bg-transparent">
                    <span className="w-12 h-12 rounded-2xl bg-[#EAF1FF] dark:bg-blue-500/10 inline-flex items-center justify-center shrink-0">
                      <PhoneForwarded className="w-5 h-5 text-blue-600 dark:text-blue-300" />
                    </span>
                    <div className="min-w-0">
                      <div className="text-xl font-black text-gray-900 dark:text-white">
                        Call Later
                      </div>
                      <div className="text-sm text-gray-500 dark:text-gray-300">
                        Customer requested a callback — schedule the next call
                        time.
                      </div>
                    </div>
                  </div>

                  <div className="px-5 py-5">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <label className="text-sm font-extrabold text-gray-700 dark:text-gray-200">
                          Call Back Date <span className="text-red-500">*</span>
                        </label>
                        <div className="mt-2 relative">
                          <CalendarDays className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                          <input
                            type="date"
                            className={`${panelInputCls} pl-10`}
                            value={callLaterDate}
                            onChange={(e) => {
                              const d = e.target.value;
                              setCallLaterDate(d);

                              const remark = [
                                callLaterRemark,
                                callLaterTime
                                  ? `(Call @ ${callLaterTime})`
                                  : "",
                              ]
                                .filter(Boolean)
                                .join(" ");

                              setFollowupForm((p) => ({
                                ...p,
                                FOLLOWUP_DATE: d,
                                FOLLOWUP_TIME: callLaterTime || "",
                                FOLLOWUP_STATUS: "PROMISED",
                                REMARKS: remark,
                              }));
                            }}
                          />
                        </div>
                      </div>

                      <div>
                        <label className="text-sm font-extrabold text-gray-700 dark:text-gray-200">
                          Call Back Time
                        </label>
                        <div className="mt-2 relative">
                          <Clock className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                          <input
                            type="time"
                            className={`${panelInputCls} pl-10`}
                            value={callLaterTime}
                            onChange={(e) => {
                              const t = e.target.value;
                              setCallLaterTime(t);

                              const remark = [
                                callLaterRemark,
                                t ? `(Call @ ${t})` : "",
                              ]
                                .filter(Boolean)
                                .join(" ");

                              setFollowupForm((p) => ({
                                ...p,
                                FOLLOWUP_DATE: callLaterDate,
                                FOLLOWUP_TIME: t || "",
                                FOLLOWUP_STATUS: "PROMISED",
                                REMARKS: remark,
                              }));
                            }}
                          />
                        </div>
                      </div>

                      <div>
                        <label className="text-sm font-extrabold text-gray-700 dark:text-gray-200">
                          Remark
                        </label>
                        <div className="mt-2 relative">
                          <PencilLine className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                          <input
                            type="text"
                            className={`${panelInputCls} pl-10`}
                            value={callLaterRemark}
                            onChange={(e) => {
                              const r = e.target.value;
                              setCallLaterRemark(r);

                              const remark = [
                                r,
                                callLaterTime
                                  ? `(Call @ ${callLaterTime})`
                                  : "",
                              ]
                                .filter(Boolean)
                                .join(" ");

                              setFollowupForm((p) => ({
                                ...p,
                                FOLLOWUP_DATE: callLaterDate,
                                FOLLOWUP_TIME: callLaterTime || "",
                                FOLLOWUP_STATUS: "PROMISED",
                                REMARKS: remark,
                              }));
                            }}
                          />
                        </div>
                      </div>
                    </div>

                    <div className="mt-5">
                      <button
                        type="button"
                        disabled={isSaving}
                        onClick={() => {
                          if (!callLaterDate) {
                            showSideAlert(
                              "Please select call back date",
                              "warning"
                            );
                            return;
                          }

                          const remark = [
                            callLaterRemark,
                            callLaterTime ? `(Call @ ${callLaterTime})` : "",
                          ]
                            .filter(Boolean)
                            .join(" ");

                          quickSet({
                            FOLLOWUP_DATE: callLaterDate,
                            FOLLOWUP_TIME: callLaterTime,
                            FOLLOWUP_STATUS: "PROMISED",
                            REMARKS: remark,
                          });

                          onSave({
                            FOLLOWUP_DATE: callLaterDate,
                            FOLLOWUP_TIME: callLaterTime,
                            FOLLOWUP_STATUS: "PROMISED",
                            REMARKS: remark,
                          });
                        }}
                        className={`inline-flex items-center gap-2 rounded-xl px-6 py-3 text-sm font-extrabold shadow-lg transition
                          bg-[#2F5BFF] hover:bg-[#274CF0] text-white
                          ${isSaving ? "opacity-60 cursor-not-allowed" : ""}`}
                      >
                        <Save className="w-4 h-4" />
                        {isSaving ? "Saving…" : "Save & Set Follow-up"}
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* CLOSE panel */}
              {activeAction === "CLOSE" && (
                <div className="rounded-2xl border border-[#E6ECF7] dark:border-borderColor-dark bg-white dark:bg-white/5 shadow-sm overflow-hidden">
                  <div className="px-5 py-5 flex items-start gap-4 border-b border-[#E6ECF7] dark:border-borderColor-dark bg-[#FBFCFF] dark:bg-transparent">
                    <span className="w-12 h-12 rounded-2xl bg-[#FFF1F2] dark:bg-red-500/10 inline-flex items-center justify-center shrink-0">
                      <XCircle className="w-5 h-5 text-red-600 dark:text-red-300" />
                    </span>
                    <div className="min-w-0">
                      <div className="text-xl font-black text-gray-900 dark:text-white">
                        Close
                      </div>
                      <div className="text-sm text-gray-500 dark:text-gray-300">
                        Mark as not interested and close the follow-up.
                      </div>
                    </div>
                  </div>

                  <div className="px-5 py-5">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="text-sm font-extrabold text-gray-700 dark:text-gray-200">
                          Remark <span className="text-red-500">*</span>
                        </label>
                        <div className="mt-2 relative">
                          <PencilLine className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                          <input
                            type="text"
                            className={`${panelInputCls} pl-10`}
                            value={closeRemark}
                            onChange={(e) => setCloseRemark(e.target.value)}
                          />
                        </div>
                      </div>

                      <div>
                        <label className="text-sm font-extrabold text-gray-700 dark:text-gray-200">
                          Follow-up Date
                        </label>
                        <div className="mt-2 relative">
                          <CalendarDays className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                          <input
                            type="date"
                            className={`${panelInputCls} pl-10 opacity-70`}
                            value={todayYMD()}
                            disabled
                          />
                        </div>
                      </div>
                    </div>

                    <div className="mt-5">
                      <button
                        type="button"
                        disabled={isSaving}
                        onClick={() => {
                          const d = todayYMD();
                          quickSet({
                            FOLLOWUP_DATE: d,
                            FOLLOWUP_STATUS: "NOT_INTERESTED",
                            REMARKS: closeRemark || "Not interested",
                          });
                          onSave({
                            FOLLOWUP_DATE: d,
                            FOLLOWUP_STATUS: "NOT_INTERESTED",
                            REMARKS: closeRemark || "Not interested",
                          });
                        }}
                        className={`inline-flex items-center gap-2 rounded-xl px-6 py-3 text-sm font-extrabold shadow-lg transition
                          bg-[#EF4444] hover:bg-[#DC2626] text-white
                          ${isSaving ? "opacity-60 cursor-not-allowed" : ""}`}
                      >
                        <XCircle className="w-4 h-4" />
                        {isSaving ? "Saving…" : "Close (Not Interested)"}
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* RENEWED panel */}
              {activeAction === "RENEWED" && (
                <div className="rounded-2xl border border-[#E6ECF7] dark:border-borderColor-dark bg-white dark:bg-white/5 shadow-sm overflow-hidden">
                  <div className="px-5 py-5 flex items-start gap-4 border-b border-[#E6ECF7] dark:border-borderColor-dark bg-[#FBFCFF] dark:bg-transparent">
                    <span className="w-12 h-12 rounded-2xl bg-[#ECFDF5] dark:bg-emerald-500/10 inline-flex items-center justify-center shrink-0">
                      <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-300" />
                    </span>
                    <div className="min-w-0">
                      <div className="text-xl font-black text-gray-900 dark:text-white">
                        Renewed
                      </div>
                      <div className="text-sm text-gray-500 dark:text-gray-300">
                        Mark this policy as renewed.
                      </div>
                    </div>
                  </div>

                  <div className="px-5 py-5">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="text-sm font-extrabold text-gray-700 dark:text-gray-200">
                          Remark
                        </label>
                        <div className="mt-2 relative">
                          <PencilLine className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                          <input
                            type="text"
                            className={`${panelInputCls} pl-10`}
                            value={renewRemark}
                            onChange={(e) => setRenewRemark(e.target.value)}
                          />
                        </div>
                      </div>

                      <div>
                        <label className="text-sm font-extrabold text-gray-700 dark:text-gray-200">
                          Date
                        </label>
                        <div className="mt-2 relative">
                          <CalendarDays className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                          <input
                            type="date"
                            className={`${panelInputCls} pl-10 opacity-70`}
                            value={todayYMD()}
                            disabled
                          />
                        </div>
                      </div>
                    </div>

                    <div className="mt-5">
                      <button
                        type="button"
                        disabled={isSaving}
                        onClick={() => {
                          const d = todayYMD();
                          quickSet({
                            FOLLOWUP_DATE: d,
                            FOLLOWUP_STATUS: "RENEWED",
                            REMARKS: renewRemark || "Renewed",
                          });
                          onSave({
                            FOLLOWUP_DATE: d,
                            FOLLOWUP_STATUS: "RENEWED",
                            REMARKS: renewRemark || "Renewed",
                          });
                        }}
                        className={`inline-flex items-center gap-2 rounded-xl px-6 py-3 text-sm font-extrabold shadow-lg transition
                          bg-[#10B981] hover:bg-[#059669] text-white
                          ${isSaving ? "opacity-60 cursor-not-allowed" : ""}`}
                      >
                        <CheckCircle2 className="w-4 h-4" />
                        {isSaving ? "Saving…" : "Mark Renewed"}
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* MANUAL FOLLOW-UP */}
              {activeAction === "NONE" && (
                <div className="rounded-2xl border border-[#E6ECF7] dark:border-borderColor-dark bg-white dark:bg-white/5 shadow-sm overflow-hidden">
                  <div className="px-5 py-4 flex items-center gap-3 border-b border-[#E6ECF7] dark:border-borderColor-dark bg-white/70 dark:bg-transparent">
                    <span className="w-9 h-9 rounded-xl bg-[#EEF4FF] dark:bg-blue-500/10 inline-flex items-center justify-center">
                      <PencilLine className="w-4 h-4 text-blue-600 dark:text-blue-300" />
                    </span>
                    <div className="text-xs font-black tracking-widest uppercase text-gray-600 dark:text-gray-300">
                      MANUAL FOLLOW-UP
                    </div>
                    <div className="ml-2 flex-1 h-px bg-[#E6ECF7] dark:bg-white/10" />
                  </div>

                  <div className="px-5 py-5">
                    <div className="grid grid-cols-12 gap-3">
                      <div className="col-span-12 md:col-span-6">
                        <Ainput
                          title="Vehicle Reg No"
                          type="text"
                          name="VEHICAL_REG_NO"
                          redlabel=""
                          value={followupForm.VEHICAL_REG_NO}
                          handleInputChange={(n, v) =>
                            setFollowupForm((p) => ({ ...p, [n]: v }))
                          }
                          onInput={() => {}}
                          disabled
                          className="bg-gray-50 dark:bg-[#111827]"
                        />
                      </div>

                      <div className="col-span-12 md:col-span-6">
                        <Ainput
                          title="Follow Up Date"
                          type="date"
                          name="FOLLOWUP_DATE"
                          redlabel="*"
                          value={followupForm.FOLLOWUP_DATE}
                          handleInputChange={(n, v) =>
                            setFollowupForm((p) => ({ ...p, [n]: v }))
                          }
                          onInput={() => {}}
                        />
                      </div>

                      <div className="col-span-12 md:col-span-6">
                        <Ainput
                          title="Follow Up Time"
                          type="time"
                          name="FOLLOWUP_TIME"
                          redlabel=""
                          value={followupForm.FOLLOWUP_TIME}
                          handleInputChange={(n, v) =>
                            setFollowupForm((p) => ({ ...p, [n]: v }))
                          }
                          onInput={() => {}}
                        />
                      </div>

                      <div className="col-span-12 md:col-span-6">
                        <label className="flex font-bold mt-1 mb-1 text-xs text-[#193A69] dark:text-[#E2E8F0]">
                          Follow Up Status{" "}
                          <span className="text-red-500 ml-1">*</span>
                        </label>
                        <select
                          className="h-9 w-full border border-borderColor dark:border-borderColor-dark rounded px-2 bg-white dark:bg-input text-sm font-semibold"
                          value={followupForm.FOLLOWUP_STATUS}
                          onChange={(e) =>
                            setFollowupForm((p) => ({
                              ...p,
                              FOLLOWUP_STATUS: e.target.value,
                            }))
                          }
                        >
                          {FOLLOWUP_STATUSES.map((s) => (
                            <option key={s.value} value={s.value}>
                              {s.label}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div className="col-span-12 md:col-span-6">
                        <Ainput
                          title="Remarks"
                          type="text"
                          name="REMARKS"
                          redlabel=""
                          value={followupForm.REMARKS}
                          handleInputChange={(n, v) =>
                            setFollowupForm((p) => ({ ...p, [n]: v }))
                          }
                          onInput={() => {}}
                          max={100}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* HISTORY TAB */}
          {activeTab === "history" && (
            <div className="rounded-xl border border-gray-100 dark:border-borderColor-dark p-4 bg-white dark:bg-white/5">
              <SectionTitle title="Follow-up History" icon="🕘" />
              {historyLoading ? (
                <div className="text-sm text-gray-600 dark:text-gray-300">
                  Loading history...
                </div>
              ) : historyRows.length === 0 ? (
                <div className="text-sm text-gray-600 dark:text-gray-300">
                  No history found
                </div>
              ) : (
                <div className="max-h-[360px] overflow-auto">
                  <table className="w-full text-xs border-collapse">
                    <thead>
                      <tr className="bg-gray-50 dark:bg-[#111827]">
                        <th className="border px-2 py-2 text-left">
                          FOLLOWUP DATE
                        </th>
                        <th className="border px-2 py-2 text-left">STATUS</th>
                        <th className="border px-2 py-2 text-left">
                          LAST FOLLOWUP DATE
                        </th>
                        <th className="border px-2 py-2 text-left">REMARKS</th>
                      </tr>
                    </thead>
                    <tbody>
                      {historyRows.map((h, idx) => (
                        <tr
                          key={idx}
                          className="hover:bg-gray-50 dark:hover:bg-[#0F172A]"
                        >
                          <td className="border px-2 py-2">
                            {ymdOnly(h.FOLLOWUP_DATE)}
                          </td>
                          <td className="border px-2 py-2">
                            {h.FOLLOWUP_STATUS || ""}
                          </td>
                          <td className="border px-2 py-2">
                            {ymdOnly(h.LAST_FOLLOWUP_DATE)}
                          </td>
                          <td className="border px-2 py-2">
                            {h.REMARKS || ""}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* AI CALLING TAB */}
          {activeTab === "aiCalling" && (
            <AiCallingTab
              row={row}
              followupForm={followupForm}
              aiGenerating={aiGenerating}
              onGenerateAiCall={onGenerateAiCall}
              aiHistoryLoading={aiHistoryLoading}
              aiHistoryRows={aiHistoryRows}
              onRefreshHistory={onLoadAiHistory}
            />
          )}
        </div>

        {/* FOOTER */}
        <div className="px-3 sm:px-5 py-3 border-t border-gray-100 dark:border-borderColor-dark bg-white dark:bg-[#111827] flex justify-end gap-2">
          <Button variant="outline" onClick={onClose} disabled={isSaving}>
            Cancel
          </Button>
          <Button
            variant="save"
            onClick={() => onSave()}
            disabled={isSaving || activeTab !== "followup"}
            title={
              activeTab !== "followup" ? "Go to Follow-up tab to save" : ""
            }
          >
            Save
          </Button>
        </div>
      </div>
    </div>
  );
};

// ============================================================
// PAGE
// ============================================================
export default function RemindersView() {
  const user = useCurrentUser();
  const router = useRouter();

  const REMINDER_API_URL = `${process.env.NEXT_PUBLIC_URL}/Crm/reminders`;
  const FOLLOWUP_SAVE_URL = `${process.env.NEXT_PUBLIC_URL}/Crm/followup`;
  const FOLLOWUP_HISTORY_URL = `${process.env.NEXT_PUBLIC_URL}/Crm/history`;
  const AI_RENEWAL_CALL_URL = `${process.env.NEXT_PUBLIC_URL}/Crm/makecall`;
  const AI_CALLING_HISTORY_URL = `${process.env.NEXT_PUBLIC_URL}/Crm/webhook`;

  const [form, setForm] = useState({
    fromDate: todayYMD(),
    toDate: todayYMD(),
  });

  const [isLoading, setIsLoading] = useState(false);
  const [tableData, setTableData] = useState<any[]>([]);

  const [detailOpen, setDetailOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<TabType>("followup");
  const [selectedRow, setSelectedRow] = useState<any>(null);

  const [followupForm, setFollowupForm] = useState({
    VEHICAL_REG_NO: "",
    FOLLOWUP_DATE: todayYMD(),
    FOLLOWUP_TIME: "",
    FOLLOWUP_STATUS: "PROMISED",
    REMARKS: "",
  });

  const [historyLoading, setHistoryLoading] = useState(false);
  const [historyRows, setHistoryRows] = useState<any[]>([]);

  const [aiGenerating, setAiGenerating] = useState(false);
  const [aiHistoryLoading, setAiHistoryLoading] = useState(false);
  const [aiHistoryRows, setAiHistoryRows] = useState<any[]>([]);

  const handleInputChange = (name: string, value: any) => {
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const columns = useMemo(
    () => [
      { Header: "TYPE", accessor: "type" },
      { Header: "DAYS", accessor: "days" },
      { Header: "MESSAGE", accessor: "message" },
      { Header: "CUST NAME", accessor: "CUST_NAME" },
      { Header: "CUST MOB NO", accessor: "CUST_MOB_NO" },
      { Header: "POLICY NAME", accessor: "POLICY_NAME" },
      { Header: "POLICY NUMBER", accessor: "POLICY_NUMBER" },
      { Header: "VEHICLE REG NO", accessor: "VEHICAL_REG_NO" },
      { Header: "MODEL NAME", accessor: "MODEL_NAME" },
      { Header: "POLICY START DATE", accessor: "POLICY_START_DATE" },
      { Header: "POLICY END DATE", accessor: "POLICY_END_DATE" },
    ],
    []
  );

  const fetchData = async () => {
    try {
      if (!form.fromDate || !form.toDate) {
        showSideAlert("Please select From Date and To Date", "warning");
        return;
      }

      setIsLoading(true);

      const payload = {
        fromDate: ymdToDmy(form.fromDate),
        toDate: ymdToDmy(form.toDate),
        loc_code: user?.branch,
      };

      const res = await axios.post(REMINDER_API_URL, payload, {
        headers: {
          accept: "application/json",
          "Content-Type": "application/json",
          compcode: user?.Comp_Code,
          name: user?.name,
        },
      });

      if (!res.data?.ok) {
        setTableData([]);
        showSideAlert(res.data?.Message || "No data", "warning");
        return;
      }

      const before = (res.data?.beforeReminders || []).map((r: any) => ({
        type: r.type,
        days: r.days,
        message: r.message,
        ...(r.data || {}),
      }));

      const after = (res.data?.afterReminders || []).map((r: any) => ({
        type: r.type,
        days: r.days,
        message: r.message,
        ...(r.data || {}),
      }));

      setTableData([...before, ...after]);
    } catch (err: any) {
      setTableData([]);
      showSideAlert(
        err?.response?.data?.Message || err?.message || "Server error",
        "error"
      );
    } finally {
      setIsLoading(false);
    }
  };

  const fetchFollowupHistoryByVehicle = async (vehNo: string) => {
    try {
      if (!vehNo) return;
      setHistoryLoading(true);

      const res = await axios.post(
        FOLLOWUP_HISTORY_URL,
        { VEHICAL_REG_NO: vehNo },
        {
          headers: {
            accept: "application/json",
            "Content-Type": "application/json",
            compcode: user?.Comp_Code,
            name: user?.name,
          },
        }
      );

      if (res.data?.ok) setHistoryRows(res.data?.data || []);
      else setHistoryRows([]);
    } catch {
      setHistoryRows([]);
    } finally {
      setHistoryLoading(false);
    }
  };

  const fetchAiCallingHistoryByVehicle = async (vehNo: string) => {
    try {
      if (!vehNo) return;
      setAiHistoryLoading(true);

      const res = await axios.post(
        AI_CALLING_HISTORY_URL,
        { vehicle_number: vehNo },
        {
          headers: {
            accept: "application/json",
            "Content-Type": "application/json",
            compcode: user?.Comp_Code,
            name: user?.name,
          },
        }
      );

      if (res.data?.Status === true) setAiHistoryRows(res.data?.data || []);
      else if (res.data?.ok === true || res.data?.success === true)
        setAiHistoryRows(res.data?.data || []);
      else setAiHistoryRows([]);
    } catch {
      setAiHistoryRows([]);
    } finally {
      setAiHistoryLoading(false);
    }
  };

  const generateAiCall = async () => {
    try {
      if (!selectedRow) {
        showSideAlert("Row not selected", "warning");
        return;
      }

      setAiGenerating(true);

      const payload = {
        utd: selectedRow?.UTD ?? null,
        policy_number: selectedRow?.POLICY_NUMBER ?? null,
        vehicle_number:
          selectedRow?.VEHICAL_REG_NO ?? followupForm.VEHICAL_REG_NO ?? null,
        Campain_ID: process.env.NEXT_PUBLIC_AI_CAMPAIGN_ID || undefined,
        customerNumber: selectedRow?.CUST_MOB_NO ?? undefined,
        showroom_name: selectedRow?.POLICY_NAME ?? undefined,
        transferNumber: process.env.NEXT_PUBLIC_AI_TRANSFER_NUMBER || undefined,
        callback_date: followupForm.FOLLOWUP_DATE
          ? ymdToMdy(followupForm.FOLLOWUP_DATE)
          : undefined,
        callback_time: followupForm.FOLLOWUP_TIME
          ? time24To12(followupForm.FOLLOWUP_TIME)
          : undefined,
      };

      const res = await axios.post(AI_RENEWAL_CALL_URL, payload, {
        headers: {
          accept: "application/json",
          "Content-Type": "application/json",
          compcode: user?.Comp_Code,
          name: user?.name,
        },
      });

      if (!(res.data?.success || res.data?.ok)) {
        showSideAlert(
          res.data?.message || res.data?.Message || "AI call failed",
          "error"
        );
        return;
      }

      showSideAlert(res.data?.message || "AI Call Triggered", "success");

      const vehNo = selectedRow?.VEHICAL_REG_NO ?? followupForm.VEHICAL_REG_NO;
      if (vehNo) await fetchAiCallingHistoryByVehicle(vehNo);
    } catch (err: any) {
      showSideAlert(
        err?.response?.data?.message ||
          err?.response?.data?.Message ||
          err?.message ||
          "AI call failed",
        "error"
      );
    } finally {
      setAiGenerating(false);
    }
  };

  const handleRowDoubleClick = (row: any) => {
    setSelectedRow(row);

    const vehNo = row?.VEHICAL_REG_NO || "";
    setFollowupForm({
      VEHICAL_REG_NO: vehNo,
      FOLLOWUP_DATE: todayYMD(),
      FOLLOWUP_TIME: "",
      FOLLOWUP_STATUS: "PROMISED",
      REMARKS: "",
    });

    setHistoryRows([]);
    setAiHistoryRows([]);

    setActiveTab("followup");
    setDetailOpen(true);
  };

  const closeDetail = () => {
    setDetailOpen(false);
    setSelectedRow(null);
    setHistoryRows([]);
    setAiHistoryRows([]);
    setActiveTab("followup");
  };

  const saveFollowup = async (
    override?: Partial<{
      FOLLOWUP_DATE: string;
      FOLLOWUP_TIME: string;
      FOLLOWUP_STATUS: string;
      REMARKS: string;
    }>
  ) => {
    try {
      const data = {
        ...followupForm,
        ...(override || {}),
      };

      if (!data.VEHICAL_REG_NO) {
        showSideAlert("Vehicle Reg No not found", "warning");
        return;
      }
      if (!data.FOLLOWUP_DATE) {
        showSideAlert("Please select Follow UP Date", "warning");
        return;
      }
      if (!data.FOLLOWUP_STATUS) {
        showSideAlert("Please select Followup Status", "warning");
        return;
      }

      setIsLoading(true);

      const payload = {
        VEHICAL_REG_NO: data.VEHICAL_REG_NO,
        FOLLOWUP_DATE: data.FOLLOWUP_DATE,
        FOLLOWUP_TIME: data.FOLLOWUP_TIME || "",
        FOLLOWUP_STATUS: data.FOLLOWUP_STATUS,
        REMARKS: data.REMARKS || "",
      };

      const res = await axios.post(FOLLOWUP_SAVE_URL, payload, {
        headers: {
          accept: "application/json",
          "Content-Type": "application/json",
          compcode: user?.Comp_Code,
          name: user?.name,
        },
      });

      if (!res.data?.ok) {
        showSideAlert(res.data?.Message || "Save failed", "error");
        return;
      }

      if (data.FOLLOWUP_DATE >= todayYMD()) {
        setTableData((prev) =>
          prev.filter(
            (r) =>
              normalizeVeh(r?.VEHICAL_REG_NO) !==
              normalizeVeh(data.VEHICAL_REG_NO)
          )
        );
      }

      setFollowupForm((prev) => ({
        ...prev,
        FOLLOWUP_DATE: data.FOLLOWUP_DATE,
        FOLLOWUP_TIME: data.FOLLOWUP_TIME || "",
        FOLLOWUP_STATUS: data.FOLLOWUP_STATUS,
        REMARKS: data.REMARKS || "",
      }));

      showSideAlert("Follow-up saved", "success");
      closeDetail();
      fetchData();
    } catch (err: any) {
      showSideAlert(
        err?.response?.data?.Message || err?.message || "Save failed",
        "error"
      );
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <div className="grid grid-cols-12 gap-3 p-3">
      <div className="col-span-12">
        <div className="rounded-t bg-header dark:bg-black px-2 md:px-6 py-2 border dark:border-borderColor-dark">
          <div className="flex items-center justify-between gap-4">
            <h1 className="font-bold sm:text-sm md:text-lg lg:text-xl text-white dark:text-[#37a9dd] uppercase">
              Reminder Table
            </h1>
            <div className="flex gap-2">
              <Button variant="print" onClick={() => router.back()}>
                Back
              </Button>
            </div>
          </div>
        </div>

        <div className="rounded-b mt-0 bg-white dark:bg-black border border-borderColor dark:border-borderColor-dark p-3 shadow">
          <div className="grid grid-cols-12 gap-3 items-end">
            <div className="col-span-12 md:col-span-3">
              <Ainput
                title="Date From"
                type="date"
                name="fromDate"
                redlabel="*"
                value={form.fromDate}
                handleInputChange={handleInputChange}
                onInput={() => {}}
              />
            </div>

            <div className="col-span-12 md:col-span-3">
              <Ainput
                title="Date To"
                type="date"
                name="toDate"
                redlabel="*"
                value={form.toDate}
                handleInputChange={handleInputChange}
                onInput={() => {}}
              />
            </div>

            <div className="col-span-12 md:col-span-2 flex gap-2">
              <Button variant="save" onClick={fetchData} disabled={isLoading}>
                Show
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* TABLE */}
      <div className="col-span-12 bg-white dark:bg-black border border-borderColor dark:border-borderColor-dark rounded p-2 shadow">
        <DataTable
          title={""}
          columns={columns}
          data={tableData}
          selectValue="UTD"
          onRowDoubleClick={handleRowDoubleClick}
          height="380px"
          filterPosition="FilterData"
          numericFilterColumns={["days", "UTD"]}
        />
      </div>

      {/* MODAL */}
      <InsuranceDetailModal
        open={detailOpen}
        row={selectedRow}
        activeTab={activeTab}
        onTabChange={setActiveTab}
        onClose={closeDetail}
        followupForm={followupForm}
        setFollowupForm={setFollowupForm}
        isSaving={isLoading}
        onSave={saveFollowup}
        historyLoading={historyLoading}
        historyRows={historyRows}
        onLoadHistory={async () => {
          if (!followupForm.VEHICAL_REG_NO) return;
          await fetchFollowupHistoryByVehicle(followupForm.VEHICAL_REG_NO);
        }}
        aiGenerating={aiGenerating}
        onGenerateAiCall={generateAiCall}
        aiHistoryLoading={aiHistoryLoading}
        aiHistoryRows={aiHistoryRows}
        onLoadAiHistory={async () => {
          const vehNo =
            selectedRow?.VEHICAL_REG_NO ?? followupForm.VEHICAL_REG_NO;
          if (!vehNo) return;
          await fetchAiCallingHistoryByVehicle(vehNo);
        }}
      />

      <HashloaderComponent isLoading={isLoading} />
    </div>
  );
}